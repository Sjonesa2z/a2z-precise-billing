import type { Metadata } from "next";
import { PageHeader } from "@/components/layout/PageHeader";
import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { ProcessSteps } from "@/components/sections/ProcessSteps";
import { BenefitGrid } from "@/components/sections/BenefitGrid";
import { FinalCTA } from "@/components/sections/FinalCTA";
import { BreadcrumbSchema } from "@/components/schema/BreadcrumbSchema";

export const metadata: Metadata = {
  title: "How It Works",
  description:
    "See how A2Z Precise Billing gets started: tell us about your needs, review your workflow, build a service plan, and begin billing support.",
  alternates: { canonical: "/how-it-works" },
};

export default function HowItWorksPage() {
  return (
    <>
      <BreadcrumbSchema items={[{ label: "How It Works", href: "/how-it-works" }]} />

      <PageHeader
        eyebrow="How It Works"
        title="Getting Started With A2Z Precise Billing"
        description="A straightforward, four-step process for putting billing support in place — no long onboarding cycles or guesswork."
      />
      <Breadcrumbs items={[{ label: "How It Works", href: "/how-it-works" }]} />

      <section className="bg-white py-16 sm:py-20">
        <div className="container">
          <ProcessSteps />
        </div>
      </section>

      <section className="bg-surface py-16 sm:py-20">
        <div className="container">
          <SectionHeading align="center" title="What You Can Expect" description="Core benefits our billing support is built around." />
          <div className="mt-10">
            <BenefitGrid />
          </div>
        </div>
      </section>

      <FinalCTA />
    </>
  );
}
