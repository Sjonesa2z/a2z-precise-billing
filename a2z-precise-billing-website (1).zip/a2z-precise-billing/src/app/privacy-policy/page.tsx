import type { Metadata } from "next";
import { PageHeader } from "@/components/layout/PageHeader";
import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { siteConfig } from "@/lib/site-config";
import { BreadcrumbSchema } from "@/components/schema/BreadcrumbSchema";

export const metadata: Metadata = {
  title: "Privacy Policy",
  description: "Privacy Policy for the A2Z Precise Billing website.",
  alternates: { canonical: "/privacy-policy" },
  robots: { index: true, follow: true },
};

export default function PrivacyPolicyPage() {
  return (
    <>
      <BreadcrumbSchema items={[{ label: "Privacy Policy", href: "/privacy-policy" }]} />
      <PageHeader
        eyebrow="Legal"
        title="Privacy Policy"
        description="How A2Z Precise Billing handles information submitted through this website."
      />
      <Breadcrumbs items={[{ label: "Privacy Policy", href: "/privacy-policy" }]} />

      <section className="bg-white py-16 sm:py-20">
        <div className="container max-w-3xl">
          <div className="rounded-card border border-amber-200 bg-amber-50 p-5 text-sm leading-relaxed text-amber-900">
            <strong>Draft placeholder.</strong> This page is a general-purpose
            starting point and has not been reviewed by an attorney. Have
            legal counsel review and finalize this policy — including state-
            and industry-specific requirements — before publishing.
          </div>

          <div className="prose-content mt-8 flex flex-col gap-6 text-base leading-relaxed text-ink">
            <p>
              This Privacy Policy explains how {siteConfig.legalName} (&quot;we,&quot;
              &quot;us,&quot; or &quot;our&quot;) collects, uses, and protects information
              submitted through this website ({siteConfig.domain}). This
              policy applies to the public website only and does not
              describe how patient health information is handled on behalf
              of client practices — that is governed by separate agreements
              with each client.
            </p>

            <h2 className="font-display text-xl font-semibold text-navy-700">Information We Collect</h2>
            <p>
              When you submit a form on this website (such as the contact
              form or billing assessment request), we may collect your
              name, business/practice name, email address, phone number,
              organization type, specialty, services of interest, and any
              message you provide. We intentionally do not request patient
              names, dates of birth, insurance identification numbers,
              medical record numbers, diagnoses, or other protected health
              information through public web forms, and you should not
              submit such information through this website.
            </p>

            <h2 className="font-display text-xl font-semibold text-navy-700">How We Use Information</h2>
            <p>
              Information submitted through this website is used to respond
              to inquiries, evaluate billing assessment requests, and
              communicate about our services. We do not sell the
              information you submit through this website to third parties.
            </p>

            <h2 className="font-display text-xl font-semibold text-navy-700">Cookies &amp; Analytics</h2>
            <p>
              This website may use basic analytics tools to understand
              overall site usage. [PLACEHOLDER: list specific analytics or
              tracking tools in use, if any, once finalized.]
            </p>

            <h2 className="font-display text-xl font-semibold text-navy-700">Data Retention</h2>
            <p>
              We retain information submitted through website forms only as
              long as reasonably necessary to respond to your inquiry and
              maintain business records in accordance with applicable law.
            </p>

            <h2 className="font-display text-xl font-semibold text-navy-700">Your Choices</h2>
            <p>
              You may contact us at any time to ask what information we
              hold about you or to request that it be deleted, subject to
              any legal or contractual obligations that require us to
              retain it.
            </p>

            <h2 className="font-display text-xl font-semibold text-navy-700">Contact Us</h2>
            <p>
              Questions about this Privacy Policy can be directed to{" "}
              <a href={`mailto:${siteConfig.contact.email}`} className="font-semibold text-blue-600 hover:underline">
                {siteConfig.contact.email}
              </a>
              .
            </p>

            <p className="text-sm text-ink-soft">Last updated: [PLACEHOLDER: publish date]</p>
          </div>
        </div>
      </section>
    </>
  );
}
