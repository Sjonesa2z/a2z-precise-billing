import type { Metadata } from "next";
import { PageHeader } from "@/components/layout/PageHeader";
import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { siteConfig } from "@/lib/site-config";
import { BreadcrumbSchema } from "@/components/schema/BreadcrumbSchema";

export const metadata: Metadata = {
  title: "Terms of Service",
  description: "Terms of Service for the A2Z Precise Billing website.",
  alternates: { canonical: "/terms" },
};

export default function TermsPage() {
  return (
    <>
      <BreadcrumbSchema items={[{ label: "Terms of Service", href: "/terms" }]} />
      <PageHeader
        eyebrow="Legal"
        title="Terms of Service"
        description="Terms governing the use of this website."
      />
      <Breadcrumbs items={[{ label: "Terms of Service", href: "/terms" }]} />

      <section className="bg-white py-16 sm:py-20">
        <div className="container max-w-3xl">
          <div className="rounded-card border border-amber-200 bg-amber-50 p-5 text-sm leading-relaxed text-amber-900">
            <strong>Draft placeholder.</strong> This page is a general-purpose
            starting point and has not been reviewed by an attorney. Have
            legal counsel review and finalize these terms — and prepare a
            separate services agreement for actual client engagements —
            before publishing or onboarding clients.
          </div>

          <div className="mt-8 flex flex-col gap-6 text-base leading-relaxed text-ink">
            <p>
              These Terms of Service govern your use of the{" "}
              {siteConfig.domain} website, operated by {siteConfig.legalName}.
              By using this website, you agree to these terms. These terms
              apply to website use only and do not constitute a service
              agreement for billing or revenue cycle management services,
              which are governed by a separate signed agreement.
            </p>

            <h2 className="font-display text-xl font-semibold text-navy-700">Use of This Website</h2>
            <p>
              This website is provided for informational purposes to
              describe our services and allow prospective clients to
              request information or a billing assessment. You agree not to
              misuse this website, including attempting to access it in an
              unauthorized manner or submitting false information through
              its forms.
            </p>

            <h2 className="font-display text-xl font-semibold text-navy-700">No Protected Health Information</h2>
            <p>
              Public forms on this website are not intended for the
              submission of protected health information (PHI). Please do
              not submit patient names, dates of birth, insurance ID
              numbers, medical record numbers, diagnoses, or other PHI
              through this website.
            </p>

            <h2 className="font-display text-xl font-semibold text-navy-700">No Guarantee of Outcomes</h2>
            <p>
              Information on this website is general in nature. It does not
              guarantee specific billing outcomes, reimbursement amounts, or
              timelines, which vary by practice, payer mix, specialty, and
              other factors.
            </p>

            <h2 className="font-display text-xl font-semibold text-navy-700">Intellectual Property</h2>
            <p>
              The content, design, and branding of this website are the
              property of {siteConfig.legalName} unless otherwise noted, and
              may not be copied or reproduced without permission.
            </p>

            <h2 className="font-display text-xl font-semibold text-navy-700">Changes to These Terms</h2>
            <p>
              We may update these terms from time to time. Continued use of
              the website after changes are posted constitutes acceptance
              of the updated terms.
            </p>

            <h2 className="font-display text-xl font-semibold text-navy-700">Contact Us</h2>
            <p>
              Questions about these terms can be directed to{" "}
              <a href={`mailto:${siteConfig.contact.email}`} className="font-semibold text-blue-600 hover:underline">
                {siteConfig.contact.email}
              </a>
              .
            </p>

            <p className="text-sm text-ink-soft">Last updated: [PLACEHOLDER: publish date]</p>
          </div>
        </div>
      </section>
    </>
  );
}
