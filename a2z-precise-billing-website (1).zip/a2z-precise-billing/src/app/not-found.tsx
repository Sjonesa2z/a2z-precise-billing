import type { Metadata } from "next";
import { Button } from "@/components/ui/Button";

export const metadata: Metadata = {
  title: "Page Not Found",
  robots: { index: false, follow: false },
};

export default function NotFound() {
  return (
    <div className="container flex flex-col items-center justify-center py-24 text-center">
      <p className="font-display text-sm font-semibold text-teal-600">404</p>
      <h1 className="mt-3 font-display text-3xl font-bold text-navy-700 sm:text-4xl">
        We couldn&apos;t find that page.
      </h1>
      <p className="mt-4 max-w-md text-base text-ink-muted">
        The page you&apos;re looking for may have moved or no longer exists. Try
        heading back to the homepage or exploring our services.
      </p>
      <div className="mt-8 flex flex-col gap-3 sm:flex-row">
        <Button href="/">Back to Home</Button>
        <Button href="/services" variant="outline">
          Explore Services
        </Button>
      </div>
    </div>
  );
}
