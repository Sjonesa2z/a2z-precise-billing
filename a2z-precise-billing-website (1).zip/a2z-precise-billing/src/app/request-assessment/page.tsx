import type { Metadata } from "next";
import { PageHeader } from "@/components/layout/PageHeader";
import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { LeadForm } from "@/components/sections/LeadForm";
import { ProcessSteps } from "@/components/sections/ProcessSteps";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { BreadcrumbSchema } from "@/components/schema/BreadcrumbSchema";
import { IconCheck } from "@/components/icons";

export const metadata: Metadata = {
  title: "Request a Free Billing Assessment",
  description:
    "Request a free billing assessment from A2Z Precise Billing. Tell us about your practice and we'll review your workflow and outline a service plan.",
  alternates: { canonical: "/request-assessment" },
};

const included = [
  "A review of your current billing workflow",
  "An outline of which services fit your practice",
  "A pricing proposal based on your collections volume",
  "No obligation to move forward",
];

export default function RequestAssessmentPage() {
  return (
    <>
      <BreadcrumbSchema items={[{ label: "Request a Free Billing Assessment", href: "/request-assessment" }]} />

      <PageHeader
        eyebrow="Free Billing Assessment"
        title="Request Your Free Billing Assessment"
        description="Tell us about your practice and current billing workflow. We'll review it and follow up with a service plan tailored to your needs."
      />
      <Breadcrumbs items={[{ label: "Request a Free Billing Assessment", href: "/request-assessment" }]} />

      <section className="bg-white py-16 sm:py-20">
        <div className="container grid grid-cols-1 gap-12 lg:grid-cols-[1fr_1.4fr] lg:gap-16">
          <div>
            <h2 className="font-display text-2xl font-bold text-navy-700">What&apos;s included</h2>
            <ul className="mt-6 flex flex-col gap-4">
              {included.map((item) => (
                <li key={item} className="flex items-start gap-3">
                  <IconCheck className="mt-0.5 h-5 w-5 shrink-0 text-teal-500" />
                  <span className="text-sm leading-relaxed text-ink">{item}</span>
                </li>
              ))}
            </ul>

            <div className="mt-10 border-t border-border pt-8">
              <SectionHeading as="h3" title="What happens next" />
              <div className="mt-6">
                <ProcessSteps />
              </div>
            </div>
          </div>

          <div className="rounded-card border border-border bg-white p-6 shadow-card sm:p-8">
            <h2 className="font-display text-xl font-bold text-navy-700">Get Started</h2>
            <p className="mt-2 text-sm text-ink-muted">
              Complete the form below and a member of our team will follow up.
            </p>
            <div className="mt-6">
              <LeadForm />
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
