import { NextResponse } from "next/server";

/**
 * Lead form submission endpoint.
 *
 * This is a functional stub: it validates the payload shape and returns
 * a success response, but does not yet deliver the lead anywhere. Before
 * launch, connect this handler to a real destination (e.g. an email
 * delivery service, CRM, or spreadsheet integration) using server-side
 * environment variables — never hardcode credentials in source.
 */

interface LeadPayload {
  fullName: string;
  company: string;
  email: string;
  phone: string;
  organizationType: string;
  specialty: string;
  servicesNeeded: string[];
  claimVolume: string;
  message?: string;
}

function isValidPayload(data: unknown): data is LeadPayload {
  if (!data || typeof data !== "object") return false;
  const d = data as Record<string, unknown>;
  return (
    typeof d.fullName === "string" &&
    d.fullName.trim().length > 0 &&
    typeof d.company === "string" &&
    d.company.trim().length > 0 &&
    typeof d.email === "string" &&
    /.+@.+\..+/.test(d.email) &&
    typeof d.phone === "string" &&
    d.phone.trim().length > 0
  );
}

export async function POST(request: Request) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ ok: false, error: "Invalid request body." }, { status: 400 });
  }

  if (!isValidPayload(body)) {
    return NextResponse.json(
      { ok: false, error: "Please complete all required fields with valid values." },
      { status: 422 }
    );
  }

  // TODO: Deliver `body` to a real destination (email service, CRM, etc.)
  // before launch. Intentionally not logging PII-adjacent fields beyond
  // what is necessary for local debugging.
  console.info("[lead-form] New lead received", {
    company: body.company,
    organizationType: body.organizationType,
  });

  return NextResponse.json({ ok: true });
}
