import type { Metadata } from "next";
import Link from "next/link";
import { PageHeader } from "@/components/layout/PageHeader";
import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { blogPosts } from "@/data/blog";
import { BreadcrumbSchema } from "@/components/schema/BreadcrumbSchema";
import { IconArrowRight } from "@/components/icons";

export const metadata: Metadata = {
  title: "Blog",
  description:
    "Articles from A2Z Precise Billing on medical billing, coding, denial management, DME billing, and revenue cycle management.",
  alternates: { canonical: "/blog" },
};

export default function BlogIndexPage() {
  return (
    <>
      <BreadcrumbSchema items={[{ label: "Blog", href: "/blog" }]} />

      <PageHeader
        eyebrow="Blog"
        title="Medical Billing Insights"
        description="Practical articles on billing, coding, and revenue cycle management topics."
      />
      <Breadcrumbs items={[{ label: "Blog", href: "/blog" }]} />

      <section className="bg-white py-16 sm:py-20">
        <div className="container">
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
            {blogPosts.map((post) => (
              <Link
                key={post.slug}
                href={`/blog/${post.slug}`}
                className="group flex flex-col rounded-card border border-border bg-white p-7 transition-shadow hover:shadow-card"
              >
                <div className="flex items-center gap-3 text-xs font-semibold uppercase tracking-wide text-teal-600">
                  <span>{post.category}</span>
                  <span className="text-ink-soft">•</span>
                  <span className="text-ink-soft normal-case">{post.readTime}</span>
                </div>
                <h2 className="mt-3 font-display text-xl font-semibold text-navy-700">{post.title}</h2>
                <p className="mt-3 flex-1 text-sm leading-relaxed text-ink-muted">{post.excerpt}</p>
                <span className="mt-5 inline-flex items-center gap-1.5 text-sm font-semibold text-blue-600">
                  Read article
                  <IconArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
                </span>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
