import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { blogPosts, getBlogPostBySlug } from "@/data/blog";
import { PageHeader } from "@/components/layout/PageHeader";
import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { FinalCTA } from "@/components/sections/FinalCTA";
import { BreadcrumbSchema } from "@/components/schema/BreadcrumbSchema";
import { siteConfig } from "@/lib/site-config";
import Link from "next/link";

interface BlogPostPageProps {
  params: { slug: string };
}

export function generateStaticParams() {
  return blogPosts.map((post) => ({ slug: post.slug }));
}

export function generateMetadata({ params }: BlogPostPageProps): Metadata {
  const post = getBlogPostBySlug(params.slug);
  if (!post) return {};

  return {
    title: post.title,
    description: post.excerpt,
    alternates: { canonical: `/blog/${post.slug}` },
    openGraph: {
      title: `${post.title} | ${siteConfig.name}`,
      description: post.excerpt,
      type: "article",
    },
  };
}

export default function BlogPostPage({ params }: BlogPostPageProps) {
  const post = getBlogPostBySlug(params.slug);
  if (!post) notFound();

  const otherPosts = blogPosts.filter((p) => p.slug !== post.slug).slice(0, 2);

  const articleSchema = {
    "@context": "https://schema.org",
    "@type": "Article",
    headline: post.title,
    description: post.excerpt,
    author: { "@type": "Organization", name: siteConfig.name },
    publisher: { "@type": "Organization", name: siteConfig.name },
    mainEntityOfPage: `${siteConfig.url}/blog/${post.slug}`,
  };

  return (
    <>
      <BreadcrumbSchema
        items={[
          { label: "Blog", href: "/blog" },
          { label: post.title, href: `/blog/${post.slug}` },
        ]}
      />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(articleSchema) }} />

      <PageHeader eyebrow={post.category} title={post.title} description={post.excerpt} />
      <Breadcrumbs
        items={[
          { label: "Blog", href: "/blog" },
          { label: post.title, href: `/blog/${post.slug}` },
        ]}
      />

      <article className="bg-white py-16 sm:py-20">
        <div className="container max-w-3xl">
          <p className="text-sm font-medium text-ink-soft">{post.readTime}</p>
          <div className="mt-6 flex flex-col gap-5">
            {post.content.map((paragraph, index) => (
              <p key={index} className="text-base leading-relaxed text-ink">
                {paragraph}
              </p>
            ))}
          </div>

          <div className="mt-10 rounded-card border border-border bg-surface p-6">
            <p className="text-sm leading-relaxed text-ink-muted">
              Have questions about how this applies to your practice?{" "}
              <Link href="/contact" className="font-semibold text-blue-600 hover:underline">
                Contact us
              </Link>{" "}
              or{" "}
              <Link href="/request-assessment" className="font-semibold text-blue-600 hover:underline">
                request a free billing assessment
              </Link>
              .
            </p>
          </div>
        </div>
      </article>

      {otherPosts.length > 0 ? (
        <section className="bg-surface py-16 sm:py-20">
          <div className="container">
            <h2 className="font-display text-2xl font-bold text-navy-700">More Articles</h2>
            <div className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-2">
              {otherPosts.map((related) => (
                <Link
                  key={related.slug}
                  href={`/blog/${related.slug}`}
                  className="rounded-card border border-border bg-white p-6 transition-shadow hover:shadow-card"
                >
                  <p className="text-xs font-semibold uppercase tracking-wide text-teal-600">{related.category}</p>
                  <h3 className="mt-2 font-display text-lg font-semibold text-navy-700">{related.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-ink-muted">{related.excerpt}</p>
                </Link>
              ))}
            </div>
          </div>
        </section>
      ) : null}

      <FinalCTA />
    </>
  );
}
