import type { Metadata } from "next";
import { PageHeader } from "@/components/layout/PageHeader";
import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { Button } from "@/components/ui/Button";
import { BreadcrumbSchema } from "@/components/schema/BreadcrumbSchema";
import { IconShieldAlert } from "@/components/icons";

export const metadata: Metadata = {
  title: "HIPAA & Security",
  description:
    "Information about how A2Z Precise Billing approaches data handling and security for healthcare billing engagements.",
  alternates: { canonical: "/hipaa-security" },
};

export default function HipaaSecurityPage() {
  return (
    <>
      <BreadcrumbSchema items={[{ label: "HIPAA & Security", href: "/hipaa-security" }]} />
      <PageHeader
        eyebrow="Security"
        title="HIPAA & Security"
        description="What healthcare organizations should know about data handling before engaging A2Z Precise Billing."
      />
      <Breadcrumbs items={[{ label: "HIPAA & Security", href: "/hipaa-security" }]} />

      <section className="bg-white py-16 sm:py-20">
        <div className="container max-w-3xl">
          <div className="flex items-start gap-3 rounded-card border border-border bg-surface p-5">
            <IconShieldAlert className="mt-0.5 h-5 w-5 shrink-0 text-teal-600" />
            <p className="text-sm leading-relaxed text-ink-muted">
              This page does not represent a certification of HIPAA
              compliance. HIPAA compliance depends on the specific
              administrative, physical, and technical safeguards in place
              for a given engagement, as well as the terms of any Business
              Associate Agreement (BAA). No website claim substitutes for
              that review.
            </p>
          </div>

          <div className="mt-10 flex flex-col gap-6 text-base leading-relaxed text-ink">
            <h2 className="font-display text-xl font-semibold text-navy-700">
              Why this matters
            </h2>
            <p>
              As a medical billing and revenue cycle management provider,
              A2Z Precise Billing may handle information related to patient
              accounts and claims on behalf of client practices. Healthcare
              organizations are responsible for ensuring that any vendor
              handling this kind of information — including A2Z Precise
              Billing — operates under an appropriate Business Associate
              Agreement and follows safeguards consistent with the
              organization&apos;s own compliance obligations.
            </p>

            <h2 className="font-display text-xl font-semibold text-navy-700">
              What this website does — and does not — collect
            </h2>
            <p>
              Public forms on this marketing website (such as the contact
              form and billing assessment request) are intentionally
              limited to business and contact information. They are not
              designed or intended to collect protected health information
              (PHI), and you should not submit patient names, dates of
              birth, insurance ID numbers, medical record numbers,
              diagnoses, or other PHI through this website.
            </p>
            <p>
              Any actual exchange of claims data or PHI as part of a billing
              engagement takes place through separate, agreed-upon channels
              and systems — not through this public website — and is
              governed by the terms of a signed service agreement and BAA.
            </p>

            <h2 className="font-display text-xl font-semibold text-navy-700">
              Discussing your organization&apos;s requirements
            </h2>
            <p>
              Every healthcare organization has different compliance
              requirements, systems, and risk tolerance. Rather than list
              generic claims here, we encourage you to contact us directly
              to discuss:
            </p>
            <ul className="list-disc space-y-2 pl-6">
              <li>The specific safeguards relevant to your engagement</li>
              <li>Business Associate Agreement terms</li>
              <li>How data would be exchanged between our teams</li>
              <li>Any compliance documentation your organization requires</li>
            </ul>

            <div className="mt-4">
              <Button href="/contact" size="lg">
                Contact Us About Security &amp; Data Handling
              </Button>
            </div>

            <p className="text-sm text-ink-soft">Last updated: [PLACEHOLDER: publish date]</p>
          </div>
        </div>
      </section>
    </>
  );
}
