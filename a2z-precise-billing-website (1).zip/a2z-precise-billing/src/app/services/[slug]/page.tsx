import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Link from "next/link";
import { services, getServiceBySlug } from "@/data/services";
import { PageHeader } from "@/components/layout/PageHeader";
import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { Button } from "@/components/ui/Button";
import { ServiceCard } from "@/components/sections/ServiceGrid";
import { FinalCTA } from "@/components/sections/FinalCTA";
import { BreadcrumbSchema } from "@/components/schema/BreadcrumbSchema";
import { IconCheck } from "@/components/icons";
import { siteConfig } from "@/lib/site-config";

interface ServicePageProps {
  params: { slug: string };
}

export function generateStaticParams() {
  return services.map((service) => ({ slug: service.slug }));
}

export function generateMetadata({ params }: ServicePageProps): Metadata {
  const service = getServiceBySlug(params.slug);
  if (!service) return {};

  return {
    title: `${service.name} Services`,
    description: service.shortDescription,
    alternates: { canonical: `/services/${service.slug}` },
    openGraph: {
      title: `${service.name} Services | ${siteConfig.name}`,
      description: service.shortDescription,
    },
  };
}

export default function ServiceDetailPage({ params }: ServicePageProps) {
  const service = getServiceBySlug(params.slug);
  if (!service) notFound();

  const Icon = service.icon;
  const relatedServices = services.filter((s) => s.slug !== service.slug).slice(0, 3);

  const serviceSchema = {
    "@context": "https://schema.org",
    "@type": "Service",
    name: service.name,
    description: service.description,
    url: `${siteConfig.url}/services/${service.slug}`,
    provider: { "@type": "MedicalBusiness", name: siteConfig.name },
    areaServed: "US",
  };

  return (
    <>
      <BreadcrumbSchema
        items={[
          { label: "Services", href: "/services" },
          { label: service.name, href: `/services/${service.slug}` },
        ]}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(serviceSchema) }}
      />

      <PageHeader eyebrow="Services" title={`${service.name} Services`} description={service.shortDescription} background="hex" />
      <Breadcrumbs
        items={[
          { label: "Services", href: "/services" },
          { label: service.name, href: `/services/${service.slug}` },
        ]}
      />

      <section className="bg-white py-16 sm:py-20">
        <div className="container grid grid-cols-1 gap-12 lg:grid-cols-[1.6fr_1fr] lg:gap-16">
          <div>
            <span className="flex h-12 w-12 items-center justify-center rounded-control bg-blue-50 text-blue-600">
              <Icon className="h-6 w-6" />
            </span>
            <h2 className="mt-5 font-display text-2xl font-bold text-navy-700 sm:text-3xl">
              How our {service.name.toLowerCase()} support works
            </h2>
            <p className="mt-4 max-w-prose text-base leading-relaxed text-ink-muted">{service.description}</p>

            <h3 className="mt-8 font-display text-lg font-semibold text-navy-700">What&apos;s included</h3>
            <ul className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
              {service.highlights.map((highlight) => (
                <li key={highlight} className="flex items-start gap-2.5 rounded-control border border-border bg-surface px-4 py-3 text-sm text-ink">
                  <IconCheck className="mt-0.5 h-4 w-4 shrink-0 text-teal-500" />
                  {highlight}
                </li>
              ))}
            </ul>

            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Button href="/request-assessment" size="lg">
                Get a Free Billing Assessment
              </Button>
              <Button href="/contact" variant="outline" size="lg">
                Ask a Question
              </Button>
            </div>
          </div>

          <aside className="rounded-card border border-border bg-surface p-6">
            <h3 className="font-display text-base font-semibold text-navy-700">Who this service is for</h3>
            <p className="mt-2 text-sm leading-relaxed text-ink-muted">
              Physicians, medical practices, clinics, home health agencies, DME
              providers, and healthcare organizations that need dedicated
              support with {service.name.toLowerCase()}.
            </p>
            <div className="mt-5 border-t border-border pt-5">
              <h3 className="font-display text-base font-semibold text-navy-700">Pricing</h3>
              <p className="mt-2 text-sm leading-relaxed text-ink-muted">
                $500/month flat for practices collecting up to $15,000/month,
                or 3% of monthly collections above that. See{" "}
                <Link href="/pricing" className="font-semibold text-blue-600 hover:underline">
                  full pricing details
                </Link>
                .
              </p>
            </div>
          </aside>
        </div>
      </section>

      <section className="bg-surface py-16 sm:py-20">
        <div className="container">
          <SectionHeading title="Related Services" />
          <div className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {relatedServices.map((related) => (
              <ServiceCard key={related.slug} service={related} />
            ))}
          </div>
        </div>
      </section>

      <FinalCTA />
    </>
  );
}
