import type { Metadata } from "next";
import { PageHeader } from "@/components/layout/PageHeader";
import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { ServiceGrid } from "@/components/sections/ServiceGrid";
import { FAQAccordion } from "@/components/sections/FAQAccordion";
import { FinalCTA } from "@/components/sections/FinalCTA";
import { BreadcrumbSchema } from "@/components/schema/BreadcrumbSchema";
import { ServiceListSchema } from "@/components/schema/ServiceSchema";
import { FaqSchema } from "@/components/schema/FaqSchema";
import { homeFaqs } from "@/data/faqs";

export const metadata: Metadata = {
  title: "Medical Billing Services",
  description:
    "Explore A2Z Precise Billing's medical billing, coding, denial management, A/R follow-up, DME billing, home health billing, and revenue cycle management services.",
  alternates: { canonical: "/services" },
};

const serviceFaqs = homeFaqs.slice(0, 6);

export default function ServicesPage() {
  return (
    <>
      <BreadcrumbSchema items={[{ label: "Services", href: "/services" }]} />
      <ServiceListSchema />
      <FaqSchema items={serviceFaqs} />

      <PageHeader
        eyebrow="Services"
        title="Medical Billing & Revenue Cycle Management Services"
        description="From charge entry through final payment posting, we support the core billing functions physicians, practices, clinics, home health agencies, and DME providers rely on."
        background="hex"
      />
      <Breadcrumbs items={[{ label: "Services", href: "/services" }]} />

      <section className="bg-white py-16 sm:py-20">
        <div className="container">
          <SectionHeading
            title="Our Core Services"
            description="Select a service below to learn more about how we support that part of your billing cycle."
          />
          <div className="mt-10">
            <ServiceGrid />
          </div>
        </div>
      </section>

      <section className="bg-surface py-16 sm:py-20">
        <div className="container">
          <SectionHeading align="center" title="Frequently Asked Questions" />
          <div className="mx-auto mt-10 max-w-3xl">
            <FAQAccordion items={serviceFaqs} />
          </div>
        </div>
      </section>

      <FinalCTA />
    </>
  );
}
