import type { Metadata } from "next";
import { PageHeader } from "@/components/layout/PageHeader";
import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { Button } from "@/components/ui/Button";
import { FAQAccordion } from "@/components/sections/FAQAccordion";
import { FinalCTA } from "@/components/sections/FinalCTA";
import { BreadcrumbSchema } from "@/components/schema/BreadcrumbSchema";
import { FaqSchema } from "@/components/schema/FaqSchema";
import { pricingFaqs } from "@/data/faqs";
import { IconCheck } from "@/components/icons";

export const metadata: Metadata = {
  title: "Pricing",
  description:
    "Simple, volume-based pricing for medical billing services: $500/month flat for practices up to $15,000/month in collections, or 3% of collections above that.",
  alternates: { canonical: "/pricing" },
};

const tiers = [
  {
    name: "Standard Practices",
    subtitle: "Up to $15,000 in monthly collections",
    price: "$500",
    period: "per month",
    description: "A predictable flat monthly rate for practices with lower monthly collection volume.",
    features: [
      "Medical billing support",
      "Claim submission & tracking",
      "Eligibility verification",
      "Payment posting",
      "A/R follow-up",
    ],
  },
  {
    name: "Growth Practices",
    subtitle: "Over $15,000 in monthly collections",
    price: "3%",
    period: "of monthly collections",
    description: "Pricing that scales with your collections as your practice grows.",
    features: [
      "Everything in Standard",
      "Denial management",
      "Prior authorization coordination",
      "Dedicated billing support",
      "Ongoing revenue cycle visibility",
    ],
  },
];

export default function PricingPage() {
  return (
    <>
      <BreadcrumbSchema items={[{ label: "Pricing", href: "/pricing" }]} />
      <FaqSchema items={pricingFaqs} />

      <PageHeader
        eyebrow="Pricing"
        title="Simple, Volume-Based Pricing"
        description="Every practice and healthcare organization has different billing volumes, specialties, workflows, and service requirements. Our base structure is shown below — contact us for a proposal specific to your practice."
        background="network"
      />
      <Breadcrumbs items={[{ label: "Pricing", href: "/pricing" }]} />

      <section className="bg-white py-16 sm:py-20">
        <div className="container">
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
            {tiers.map((tier) => (
              <div key={tier.name} className="flex flex-col rounded-card border border-border bg-white p-8 shadow-card">
                <p className="text-sm font-semibold text-teal-600">{tier.subtitle}</p>
                <h2 className="mt-2 font-display text-2xl font-bold text-navy-700">{tier.name}</h2>
                <p className="mt-4 font-display text-4xl font-bold text-navy-700">
                  {tier.price}
                  <span className="ml-1 text-base font-medium text-ink-muted">/ {tier.period}</span>
                </p>
                <p className="mt-3 text-sm leading-relaxed text-ink-muted">{tier.description}</p>
                <ul className="mt-6 flex flex-1 flex-col gap-2.5">
                  {tier.features.map((feature) => (
                    <li key={feature} className="flex items-start gap-2.5 text-sm text-ink">
                      <IconCheck className="mt-0.5 h-4 w-4 shrink-0 text-teal-500" />
                      {feature}
                    </li>
                  ))}
                </ul>
                <Button href="/contact" className="mt-8">
                  Request Custom Pricing
                </Button>
              </div>
            ))}
          </div>

          <p className="mx-auto mt-10 max-w-2xl text-center text-sm leading-relaxed text-ink-muted">
            Pricing tiers are based on total monthly collections. Contact us
            to confirm which structure applies to your practice and to
            discuss any additional services you may need, such as
            credentialing or specialty-specific coding support.
          </p>
        </div>
      </section>

      <section className="bg-surface py-16 sm:py-20">
        <div className="container">
          <SectionHeading align="center" title="Pricing FAQs" />
          <div className="mx-auto mt-10 max-w-3xl">
            <FAQAccordion items={pricingFaqs} />
          </div>
        </div>
      </section>

      <FinalCTA />
    </>
  );
}
