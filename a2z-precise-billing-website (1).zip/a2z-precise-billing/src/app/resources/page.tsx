import type { Metadata } from "next";
import Link from "next/link";
import { PageHeader } from "@/components/layout/PageHeader";
import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { FAQAccordion } from "@/components/sections/FAQAccordion";
import { FinalCTA } from "@/components/sections/FinalCTA";
import { BreadcrumbSchema } from "@/components/schema/BreadcrumbSchema";
import { FaqSchema } from "@/components/schema/FaqSchema";
import { homeFaqs } from "@/data/faqs";
import { blogPosts } from "@/data/blog";
import { IconArrowRight } from "@/components/icons";

export const metadata: Metadata = {
  title: "Resources",
  description:
    "Medical billing guides, FAQs, and articles from A2Z Precise Billing covering denial management, coding, DME billing, and revenue cycle management.",
  alternates: { canonical: "/resources" },
};

export default function ResourcesPage() {
  return (
    <>
      <BreadcrumbSchema items={[{ label: "Resources", href: "/resources" }]} />
      <FaqSchema items={homeFaqs} />

      <PageHeader
        eyebrow="Resources"
        title="Medical Billing Resources"
        description="Guides, articles, and answers to common questions about medical billing, coding, and revenue cycle management."
        background="flow"
      />
      <Breadcrumbs items={[{ label: "Resources", href: "/resources" }]} />

      <section className="bg-white py-16 sm:py-20">
        <div className="container">
          <div className="flex items-end justify-between">
            <SectionHeading title="From the Blog" description="Articles on billing, coding, and revenue cycle topics." />
            <Link href="/blog" className="hidden text-sm font-semibold text-blue-600 hover:underline sm:block">
              View all posts
            </Link>
          </div>
          <div className="mt-10 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {blogPosts.map((post) => (
              <Link
                key={post.slug}
                href={`/blog/${post.slug}`}
                className="group flex flex-col rounded-card border border-border bg-white p-6 transition-shadow hover:shadow-card"
              >
                <p className="text-xs font-semibold uppercase tracking-wide text-teal-600">{post.category}</p>
                <h3 className="mt-3 font-display text-lg font-semibold text-navy-700">{post.title}</h3>
                <p className="mt-2 flex-1 text-sm leading-relaxed text-ink-muted">{post.excerpt}</p>
                <span className="mt-4 inline-flex items-center gap-1.5 text-sm font-semibold text-blue-600">
                  Read article
                  <IconArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
                </span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-surface py-16 sm:py-20">
        <div className="container">
          <SectionHeading align="center" title="Frequently Asked Questions" />
          <div className="mx-auto mt-10 max-w-3xl">
            <FAQAccordion items={homeFaqs} />
          </div>
        </div>
      </section>

      <FinalCTA />
    </>
  );
}
