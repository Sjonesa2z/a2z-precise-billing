import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { specialties, getSpecialtyBySlug } from "@/data/specialties";
import { PageHeader } from "@/components/layout/PageHeader";
import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { Button } from "@/components/ui/Button";
import { ServiceGrid } from "@/components/sections/ServiceGrid";
import { FinalCTA } from "@/components/sections/FinalCTA";
import { BreadcrumbSchema } from "@/components/schema/BreadcrumbSchema";

interface SpecialtyPageProps {
  params: { slug: string };
}

export function generateStaticParams() {
  return specialties.map((specialty) => ({ slug: specialty.slug }));
}

export function generateMetadata({ params }: SpecialtyPageProps): Metadata {
  const specialty = getSpecialtyBySlug(params.slug);
  if (!specialty) return {};

  return {
    title: `${specialty.name} Billing Services`,
    description: specialty.description,
    alternates: { canonical: `/specialties/${specialty.slug}` },
  };
}

export default function SpecialtyDetailPage({ params }: SpecialtyPageProps) {
  const specialty = getSpecialtyBySlug(params.slug);
  if (!specialty) notFound();

  return (
    <>
      <BreadcrumbSchema
        items={[
          { label: "Specialties", href: "/specialties" },
          { label: specialty.name, href: `/specialties/${specialty.slug}` },
        ]}
      />

      <PageHeader
        eyebrow="Specialties"
        title={`${specialty.name} Billing Services`}
        description={specialty.description}
      />
      <Breadcrumbs
        items={[
          { label: "Specialties", href: "/specialties" },
          { label: specialty.name, href: `/specialties/${specialty.slug}` },
        ]}
      />

      <section className="bg-white py-16 sm:py-20">
        <div className="container grid grid-cols-1 gap-12 lg:grid-cols-[1.6fr_1fr] lg:gap-16">
          <div>
            <h2 className="font-display text-2xl font-bold text-navy-700 sm:text-3xl">
              Billing support for {specialty.name.toLowerCase()} providers
            </h2>
            <p className="mt-4 max-w-prose text-base leading-relaxed text-ink-muted">
              {specialty.description} We apply the same core billing, coding,
              and revenue cycle processes across specialties, while paying
              attention to the documentation and coding conventions specific
              to {specialty.name.toLowerCase()}.
            </p>
            <p className="mt-4 max-w-prose text-base leading-relaxed text-ink-muted">
              Our services for {specialty.name.toLowerCase()} practices can
              include medical billing, medical coding support, eligibility
              verification, prior authorization coordination, denial
              management, and A/R follow-up — scoped to your practice&apos;s
              specific workflow.
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Button href="/request-assessment" size="lg">
                Get a Free Billing Assessment
              </Button>
              <Button href="/services" variant="outline" size="lg">
                View All Services
              </Button>
            </div>
          </div>

          <aside className="rounded-card border border-border bg-surface p-6">
            <h3 className="font-display text-base font-semibold text-navy-700">Not your specialty?</h3>
            <p className="mt-2 text-sm leading-relaxed text-ink-muted">
              We support a wide range of specialties beyond the list shown
              here. Contact us to discuss your practice&apos;s specific
              billing needs.
            </p>
            <Button href="/specialties" variant="outline" className="mt-4 w-full">
              View All Specialties
            </Button>
          </aside>
        </div>
      </section>

      <section className="bg-surface py-16 sm:py-20">
        <div className="container">
          <SectionHeading title="Services Available for This Specialty" />
          <div className="mt-8">
            <ServiceGrid limit={6} />
          </div>
        </div>
      </section>

      <FinalCTA />
    </>
  );
}
