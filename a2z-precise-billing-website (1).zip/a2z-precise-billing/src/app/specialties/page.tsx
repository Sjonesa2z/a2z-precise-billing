import type { Metadata } from "next";
import { PageHeader } from "@/components/layout/PageHeader";
import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { specialties } from "@/data/specialties";
import { FinalCTA } from "@/components/sections/FinalCTA";
import { BreadcrumbSchema } from "@/components/schema/BreadcrumbSchema";
import Link from "next/link";
import { IconArrowRight } from "@/components/icons";

export const metadata: Metadata = {
  title: "Specialties We Support",
  description:
    "A2Z Precise Billing supports medical billing across a wide range of specialties, including home health, DME, physical therapy, mental health, and more.",
  alternates: { canonical: "/specialties" },
};

export default function SpecialtiesPage() {
  return (
    <>
      <BreadcrumbSchema items={[{ label: "Specialties", href: "/specialties" }]} />

      <PageHeader
        eyebrow="Specialties"
        title="Billing Experience Across a Range of Medical Specialties"
        description="Billing requirements vary by specialty. We tailor our support to the documentation, coding, and payer requirements specific to your practice."
      />
      <Breadcrumbs items={[{ label: "Specialties", href: "/specialties" }]} />

      <section className="bg-white py-16 sm:py-20">
        <div className="container">
          <SectionHeading title="Select Your Specialty" />
          <div className="mt-10 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {specialties.map((specialty) => (
              <Link
                key={specialty.slug}
                href={`/specialties/${specialty.slug}`}
                className="group flex items-center justify-between rounded-card border border-border bg-white p-5 transition-colors hover:border-blue-400 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-500"
              >
                <div>
                  <h3 className="font-display text-base font-semibold text-navy-700">{specialty.name}</h3>
                  <p className="mt-1.5 text-sm leading-relaxed text-ink-muted">{specialty.description}</p>
                </div>
                <IconArrowRight className="ml-3 h-5 w-5 shrink-0 text-ink-soft transition-transform group-hover:translate-x-0.5 group-hover:text-blue-600" />
              </Link>
            ))}
          </div>
        </div>
      </section>

      <FinalCTA />
    </>
  );
}
