import type { Metadata } from "next";
import { PageHeader } from "@/components/layout/PageHeader";
import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { WhyChooseUs } from "@/components/sections/WhyChooseUs";
import { IndustryGrid } from "@/components/sections/IndustryGrid";
import { Testimonials } from "@/components/sections/Testimonials";
import { FinalCTA } from "@/components/sections/FinalCTA";
import { BreadcrumbSchema } from "@/components/schema/BreadcrumbSchema";
import { DataFlowBackground } from "@/components/backgrounds/DataFlowBackground";
import { siteConfig } from "@/lib/site-config";

export const metadata: Metadata = {
  title: "About Us",
  description:
    "A2Z Precise Billing brings 17+ years of medical billing experience to physicians, practices, clinics, home health agencies, and DME providers.",
  alternates: { canonical: "/about" },
};

const approach = [
  {
    title: "Understand your workflow first",
    description:
      "Before making changes, we take time to understand how your practice currently handles billing, coding, and follow-up.",
  },
  {
    title: "Apply a consistent process",
    description:
      "We follow a defined, repeatable process for claim submission, denial management, and A/R follow-up rather than ad-hoc handling.",
  },
  {
    title: "Stay specialty-aware",
    description:
      "Billing rules and documentation requirements differ by specialty. We tailor our support to the specialty you practice in.",
  },
  {
    title: "Communicate clearly",
    description:
      "You should always know where your claims and accounts stand. We keep communication straightforward and responsive.",
  },
];

export default function AboutPage() {
  return (
    <>
      <BreadcrumbSchema items={[{ label: "About", href: "/about" }]} />
      <PageHeader
        eyebrow="About A2Z Precise Billing"
        title="Medical billing support built on 17+ years of experience"
        description="A2Z Precise Billing provides medical billing, coding, and revenue cycle management support for physicians, practices, clinics, home health agencies, DME providers, and healthcare organizations."
        background="network"
      />
      <Breadcrumbs items={[{ label: "About", href: "/about" }]} />

      <section className="bg-white py-16 sm:py-20">
        <div className="container grid grid-cols-1 gap-12 lg:grid-cols-2 lg:gap-16">
          <div>
            <SectionHeading
              title="Who we are"
              description={`A2Z Precise Billing is a medical billing and revenue cycle management company with ${siteConfig.yearsExperience} years of experience supporting U.S. healthcare providers.`}
            />
            <p className="mt-6 max-w-prose text-base leading-relaxed text-ink-muted">
              We work with physicians, medical practices, clinics, home
              health agencies, DME providers, and healthcare organizations
              to manage core billing functions — from charge entry and
              coding support through claim submission, denial management,
              and A/R follow-up.
            </p>
            <p className="mt-4 max-w-prose text-base leading-relaxed text-ink-muted">
              Our focus is on accuracy, consistency, and clear communication
              so your team can spend less time on administrative billing
              tasks and more time on patient care.
            </p>
          </div>
          <div>
            <SectionHeading title="Our approach" />
            <ul className="mt-6 flex flex-col gap-6">
              {approach.map((item) => (
                <li key={item.title} className="border-l-2 border-teal-500 pl-4">
                  <h3 className="font-display text-base font-semibold text-navy-700">{item.title}</h3>
                  <p className="mt-1.5 text-sm leading-relaxed text-ink-muted">{item.description}</p>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <section className="bg-surface py-16 sm:py-20">
        <div className="container">
          <SectionHeading align="center" title="Why Practices Choose Us" />
          <div className="mt-10">
            <WhyChooseUs />
          </div>
        </div>
      </section>

      <section className="relative overflow-hidden bg-navy-800 py-16 sm:py-20">
        <DataFlowBackground className="pointer-events-none absolute inset-0 h-full w-full" />
        <div className="container relative">
          <SectionHeading align="center" tone="light" title="Who We Serve" />
          <div className="mt-10">
            <IndustryGrid tone="dark" />
          </div>
        </div>
      </section>

      <section className="bg-surface py-16 sm:py-20">
        <div className="container">
          <SectionHeading align="center" title="Client Feedback" />
          <div className="mt-10">
            <Testimonials />
          </div>
        </div>
      </section>

      <FinalCTA />
    </>
  );
}
