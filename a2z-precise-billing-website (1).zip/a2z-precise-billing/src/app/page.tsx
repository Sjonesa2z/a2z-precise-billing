import type { Metadata } from "next";
import Link from "next/link";
import { Hero } from "@/components/sections/Hero";
import { TrustStats } from "@/components/sections/TrustStats";
import { ServiceGrid } from "@/components/sections/ServiceGrid";
import { WhyChooseUs } from "@/components/sections/WhyChooseUs";
import { IndustryGrid } from "@/components/sections/IndustryGrid";
import { FeatureSection } from "@/components/sections/FeatureSection";
import { SpecialtyGrid } from "@/components/sections/SpecialtyGrid";
import { ProcessSteps } from "@/components/sections/ProcessSteps";
import { BenefitGrid } from "@/components/sections/BenefitGrid";
import { PricingCTA } from "@/components/sections/PricingCTA";
import { FAQAccordion } from "@/components/sections/FAQAccordion";
import { FinalCTA } from "@/components/sections/FinalCTA";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { Button } from "@/components/ui/Button";
import { ServiceListSchema } from "@/components/schema/ServiceSchema";
import { FaqSchema } from "@/components/schema/FaqSchema";
import { homeFaqs } from "@/data/faqs";
import { dmeCategories, homeHealthBillingSupport, homeHealthServices } from "@/data/feature-lists";
import { IconTruckMedical, IconHomeHeart } from "@/components/icons";
import { DataFlowBackground } from "@/components/backgrounds/DataFlowBackground";

export const metadata: Metadata = {
  title: "Medical Billing & RCM Services",
  description:
    "A2Z Precise Billing provides professional medical billing, coding, DME, home health and RCM services backed by 17+ years of billing experience.",
  alternates: {
    canonical: "/",
  },
};

export default function HomePage() {
  return (
    <>
      <ServiceListSchema />
      <FaqSchema items={homeFaqs} />

      <Hero />
      <TrustStats />

      <section id="services" className="bg-white py-16 sm:py-20">
        <div className="container">
          <div className="flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between">
            <SectionHeading
              title="Billing & RCM Services"
              description="Core services that support the full billing lifecycle, from charge entry through final payment posting."
            />
            <Button href="/services" variant="outline" className="w-full shrink-0 sm:w-auto">
              View All Services
            </Button>
          </div>
          <div className="mt-10">
            <ServiceGrid />
          </div>
        </div>
      </section>

      <section className="bg-surface py-16 sm:py-20">
        <div className="container">
          <SectionHeading
            align="center"
            title="Why Practices Choose A2Z Precise Billing"
            description="A dedicated, experience-driven approach to medical billing support."
          />
          <div className="mt-10">
            <WhyChooseUs />
          </div>
        </div>
      </section>

      <section className="relative overflow-hidden bg-navy-800 py-16 sm:py-20">
        <DataFlowBackground className="pointer-events-none absolute inset-0 h-full w-full" />
        <div className="container relative">
          <SectionHeading
            align="center"
            tone="light"
            title="Who We Serve"
            description="Billing support tailored to the way different healthcare organizations operate."
          />
          <div className="mt-10">
            <IndustryGrid tone="dark" />
          </div>
        </div>
      </section>

      <FeatureSection
        eyebrow="DME Billing"
        title="Billing Support Built for Durable Medical Equipment"
        description="DME billing involves detailed documentation and payer-specific requirements. We support claim preparation and follow-up across a wide range of equipment and supply categories."
        icon={IconTruckMedical}
        groups={[{ items: dmeCategories }]}
        ctaLabel="Explore DME Billing"
        ctaHref="/services/dme-billing"
        tone="surface"
      />

      <FeatureSection
        eyebrow="Home Health Billing"
        title="Coordinated Billing for Home Health Agencies"
        description="From visit-based services to full claims processing, we support the billing needs specific to home health agencies."
        icon={IconHomeHeart}
        groups={[
          { heading: "Visit Types", items: homeHealthServices },
          { heading: "Billing Support", items: homeHealthBillingSupport },
        ]}
        ctaLabel="Explore Home Health Billing"
        ctaHref="/services/home-health-billing"
        reverse
      />

      <section className="bg-surface py-16 sm:py-20">
        <div className="container">
          <div className="flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between">
            <SectionHeading
              title="Specialties We Support"
              description="Billing experience across a wide range of medical specialties."
            />
            <Button href="/specialties" variant="outline" className="w-full shrink-0 sm:w-auto">
              View All Specialties
            </Button>
          </div>
          <div className="mt-10">
            <SpecialtyGrid limit={10} />
          </div>
        </div>
      </section>

      <section className="bg-white py-16 sm:py-20">
        <div className="container">
          <SectionHeading
            align="center"
            title="How It Works"
            description="A straightforward process for getting billing support in place."
          />
          <div className="mt-10">
            <ProcessSteps />
          </div>
        </div>
      </section>

      <section className="bg-surface py-16 sm:py-20">
        <div className="container">
          <SectionHeading
            align="center"
            title="What You Can Expect"
            description="Core benefits our billing support is built around."
          />
          <div className="mt-10">
            <BenefitGrid />
          </div>
        </div>
      </section>

      <PricingCTA />

      <section className="bg-white py-16 sm:py-20">
        <div className="container">
          <SectionHeading align="center" title="Frequently Asked Questions" />
          <div className="mx-auto mt-10 max-w-3xl">
            <FAQAccordion items={homeFaqs} />
          </div>
          <p className="mt-6 text-center text-sm text-ink-muted">
            Have a different question?{" "}
            <Link href="/contact" className="font-semibold text-blue-600 hover:underline">
              Contact us
            </Link>
            .
          </p>
        </div>
      </section>

      <FinalCTA />
    </>
  );
}
