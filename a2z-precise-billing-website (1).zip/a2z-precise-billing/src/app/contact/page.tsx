import type { Metadata } from "next";
import { PageHeader } from "@/components/layout/PageHeader";
import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { LeadForm } from "@/components/sections/LeadForm";
import { BreadcrumbSchema } from "@/components/schema/BreadcrumbSchema";
import { siteConfig } from "@/lib/site-config";
import { IconClock, IconMail, IconPhone, IconPin } from "@/components/icons";

export const metadata: Metadata = {
  title: "Contact Us",
  description:
    "Contact A2Z Precise Billing to discuss your medical billing, coding, and revenue cycle management needs and request a customized service proposal.",
  alternates: { canonical: "/contact" },
};

const contactDetails = [
  { icon: IconPhone, label: "Phone", value: siteConfig.contact.phoneDisplay, href: siteConfig.contact.phoneHref },
  { icon: IconMail, label: "Email", value: siteConfig.contact.email, href: `mailto:${siteConfig.contact.email}` },
  {
    icon: IconPin,
    label: "Address",
    value: `${siteConfig.contact.addressLine1}, ${siteConfig.contact.addressLine2}`,
    href: undefined,
  },
  { icon: IconClock, label: "Hours", value: siteConfig.contact.hours, href: undefined },
];

export default function ContactPage() {
  return (
    <>
      <BreadcrumbSchema items={[{ label: "Contact", href: "/contact" }]} />

      <PageHeader
        eyebrow="Contact"
        title="Let's Talk About Your Billing Needs"
        description="Share a few details about your practice and we'll follow up to discuss a service plan and pricing proposal."
      />
      <Breadcrumbs items={[{ label: "Contact", href: "/contact" }]} />

      <section className="bg-white py-16 sm:py-20">
        <div className="container grid grid-cols-1 gap-12 lg:grid-cols-[1fr_1.4fr] lg:gap-16">
          <div>
            <h2 className="font-display text-2xl font-bold text-navy-700">Contact Details</h2>
            <ul className="mt-6 flex flex-col gap-5">
              {contactDetails.map((detail) => {
                const Icon = detail.icon;
                return (
                  <li key={detail.label} className="flex items-start gap-3.5">
                    <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-control bg-teal-50 text-teal-600">
                      <Icon className="h-5 w-5" />
                    </span>
                    <div>
                      <p className="text-xs font-semibold uppercase tracking-wide text-ink-soft">{detail.label}</p>
                      {detail.href ? (
                        <a href={detail.href} className="text-sm font-medium text-navy-700 hover:text-blue-600">
                          {detail.value}
                        </a>
                      ) : (
                        <p className="text-sm font-medium text-navy-700">{detail.value}</p>
                      )}
                    </div>
                  </li>
                );
              })}
            </ul>

            <div className="mt-8 rounded-card border border-border bg-surface p-5">
              <p className="text-sm leading-relaxed text-ink-muted">
                Prefer a guided assessment instead? Visit our{" "}
                <a href="/request-assessment" className="font-semibold text-blue-600 hover:underline">
                  free billing assessment
                </a>{" "}
                page to get started.
              </p>
            </div>
          </div>

          <div className="rounded-card border border-border bg-white p-6 shadow-card sm:p-8">
            <h2 className="font-display text-xl font-bold text-navy-700">Send Us a Message</h2>
            <p className="mt-2 text-sm text-ink-muted">
              Fields marked with an asterisk are required. Please avoid including
              any patient information in your message.
            </p>
            <div className="mt-6">
              <LeadForm />
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
