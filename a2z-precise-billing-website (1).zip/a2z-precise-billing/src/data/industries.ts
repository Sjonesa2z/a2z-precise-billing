import type { Industry } from "@/types";
import {
  IconStethoscope,
  IconClinic,
  IconBuilding,
  IconHomeHeart,
  IconTruckMedical,
  IconOrganization,
} from "@/components/icons";

export const industries: Industry[] = [
  {
    slug: "physicians",
    name: "Physicians",
    description: "Independent and group physicians who need reliable billing support.",
    icon: IconStethoscope,
  },
  {
    slug: "medical-practices",
    name: "Medical Practices",
    description: "Single and multi-provider practices across a range of specialties.",
    icon: IconBuilding,
  },
  {
    slug: "clinics",
    name: "Clinics",
    description: "Outpatient clinics managing high visit volumes and varied payer mixes.",
    icon: IconClinic,
  },
  {
    slug: "home-health-agencies",
    name: "Home Health Agencies",
    description: "Agencies coordinating episodic and visit-based home health billing.",
    icon: IconHomeHeart,
  },
  {
    slug: "dme-providers",
    name: "DME Providers",
    description: "Durable medical equipment suppliers with documentation-heavy claims.",
    icon: IconTruckMedical,
  },
  {
    slug: "healthcare-organizations",
    name: "Healthcare Organizations",
    description: "Larger organizations that need coordinated billing across departments.",
    icon: IconOrganization,
  },
];
