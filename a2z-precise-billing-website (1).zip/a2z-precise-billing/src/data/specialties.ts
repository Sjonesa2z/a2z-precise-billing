import type { Specialty } from "@/types";

export const specialties: Specialty[] = [
  {
    slug: "home-health",
    name: "Home Health",
    description: "Billing support for agencies delivering skilled and non-skilled home-based care.",
  },
  {
    slug: "dme",
    name: "DME",
    description: "Billing support for durable medical equipment providers and suppliers.",
  },
  {
    slug: "physical-therapy",
    name: "Physical Therapy",
    description: "Billing support for outpatient and clinic-based physical therapy practices.",
  },
  {
    slug: "mental-health",
    name: "Mental Health",
    description: "Billing support for behavioral and mental health practices and clinicians.",
  },
  {
    slug: "internal-medicine",
    name: "Internal Medicine",
    description: "Billing support for internal medicine practices managing varied visit types.",
  },
  {
    slug: "family-practice",
    name: "Family Practice",
    description: "Billing support for family practice and primary care clinics.",
  },
  {
    slug: "wound-care",
    name: "Wound Care",
    description: "Billing support for wound care providers with documentation-intensive claims.",
  },
  {
    slug: "urology",
    name: "Urology",
    description: "Billing support for urology practices and procedure-based visits.",
  },
  {
    slug: "orthopedics",
    name: "Orthopedics",
    description: "Billing support for orthopedic practices, including procedural coding needs.",
  },
  {
    slug: "pediatrics",
    name: "Pediatrics",
    description: "Billing support for pediatric practices and well-visit billing cycles.",
  },
  {
    slug: "cardiology",
    name: "Cardiology",
    description: "Billing support for cardiology practices with diagnostic and procedural claims.",
  },
  {
    slug: "gastroenterology",
    name: "Gastroenterology",
    description: "Billing support for gastroenterology practices and procedure scheduling cycles.",
  },
  {
    slug: "ob-gyn",
    name: "OB/GYN",
    description: "Billing support for OB/GYN practices, including global maternity billing needs.",
  },
  {
    slug: "dermatology",
    name: "Dermatology",
    description: "Billing support for dermatology practices with high visit and procedure volume.",
  },
  {
    slug: "other-specialties",
    name: "Other Specialties",
    description: "Don't see your specialty listed? Contact us to discuss your practice's billing needs.",
  },
];

export function getSpecialtyBySlug(slug: string): Specialty | undefined {
  return specialties.find((specialty) => specialty.slug === slug);
}
