export const dmeCategories: string[] = [
  "Prosthetics & Orthotics",
  "Mobility Devices",
  "Respiratory Equipment",
  "CPAP & BiPAP",
  "Nebulizers",
  "Suction Equipment",
  "Monitoring Equipment",
  "Breast Pumps",
  "Glucose Monitoring Equipment",
  "Continuous Glucose Monitoring",
  "Commode Chairs",
  "Shower Equipment",
];

export const homeHealthServices: string[] = [
  "Home Health Aide",
  "Nursing Care",
  "Physical Therapy",
  "Speech Therapy",
  "Respite Care",
];

export const homeHealthBillingSupport: string[] = [
  "Claims Processing",
  "Coding Support",
  "Eligibility Verification",
  "Denial Management",
  "A/R Follow-Up",
  "Payment Posting",
];
