import type { Benefit, ProcessStep } from "@/types";
import {
  IconAccuracy,
  IconLedger,
  IconWorkflow,
  IconShieldAlert,
  IconEfficiency,
  IconVisibility,
} from "@/components/icons";

export const processSteps: ProcessStep[] = [
  {
    step: 1,
    title: "Tell Us About Your Needs",
    description:
      "Share details about your practice, specialty, and current billing challenges so we understand your starting point.",
  },
  {
    step: 2,
    title: "Review Your Workflow",
    description:
      "We review your existing billing workflow, systems, and claim volume to identify where support is needed most.",
  },
  {
    step: 3,
    title: "Build Your Service Plan",
    description:
      "Based on that review, we outline a service plan and pricing structure matched to your practice's needs.",
  },
  {
    step: 4,
    title: "Begin Your Billing Support",
    description:
      "Once your plan is confirmed, we begin providing billing support according to the agreed scope and workflow.",
  },
];

export const benefits: Benefit[] = [
  {
    title: "Billing Accuracy",
    description: "A consistent, detail-oriented approach to claim preparation and submission.",
    icon: IconAccuracy,
  },
  {
    title: "A/R Management",
    description: "Regular follow-up on outstanding claims to help manage aging accounts receivable.",
    icon: IconLedger,
  },
  {
    title: "Claim Management",
    description: "Structured tracking of claims from submission through resolution.",
    icon: IconWorkflow,
  },
  {
    title: "Denial Management",
    description: "A defined process for reviewing, correcting, and resubmitting denied claims.",
    icon: IconShieldAlert,
  },
  {
    title: "Administrative Efficiency",
    description: "Billing support that reduces the administrative load on your in-house team.",
    icon: IconEfficiency,
  },
  {
    title: "Revenue Cycle Visibility",
    description: "Clearer visibility into where claims and accounts stand across the billing cycle.",
    icon: IconVisibility,
  },
];
