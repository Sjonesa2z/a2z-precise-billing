import type { FaqItem } from "@/types";

export const homeFaqs: FaqItem[] = [
  {
    question: "What medical billing services does A2Z Precise Billing provide?",
    answer:
      "We provide medical billing, medical coding support, revenue cycle management, denial management, A/R follow-up, payment posting, eligibility verification, prior authorization coordination, provider credentialing support, DME billing, and home health billing.",
  },
  {
    question: "Do you support DME billing?",
    answer:
      "Yes. We support billing for durable medical equipment providers, including documentation coordination and claim follow-up across common equipment and supply categories.",
  },
  {
    question: "Do you support home health billing?",
    answer:
      "Yes. We support home health agencies with billing for nursing, therapy, and aide visits, along with eligibility verification, coding support, and A/R follow-up.",
  },
  {
    question: "Can you help with medical coding as well as billing?",
    answer:
      "Yes. We provide coding support alongside billing, with attention to documentation review and coding consistency to help support clean claim submission.",
  },
  {
    question: "How does denial management work?",
    answer:
      "We review denied and rejected claims, identify the reason codes, correct the issue where possible, and manage timely resubmission or appeal in line with payer requirements.",
  },
  {
    question: "What does A/R follow-up involve?",
    answer:
      "We follow up on outstanding claims on a regular cycle, prioritize aging accounts, and escalate items that need additional documentation or practice input.",
  },
  {
    question: "How is pricing determined?",
    answer:
      "Pricing depends on your practice's billing volume, specialty, and service needs. Contact us to discuss your requirements and receive a customized proposal.",
  },
  {
    question: "How much experience does A2Z Precise Billing have?",
    answer:
      "A2Z Precise Billing brings 17+ years of medical billing experience supporting physicians, practices, clinics, home health agencies, and DME providers.",
  },
  {
    question: "How do we get started?",
    answer:
      "Start by requesting a free billing assessment. We'll ask about your current workflow, review your needs, and outline a service plan before beginning support.",
  },
];

export const pricingFaqs: FaqItem[] = [
  {
    question: "How is pricing structured?",
    answer:
      "Practices collecting up to $15,000 per month are billed a flat $500 monthly fee. Practices collecting more than $15,000 per month are billed 3% of total monthly collections. Contact us to confirm which structure applies to your practice.",
  },
  {
    question: "Do you require a long-term contract?",
    answer:
      "Contract terms are discussed as part of your custom proposal. Reach out to review the options available for your practice.",
  },
  {
    question: "What factors affect pricing?",
    answer:
      "Your monthly collections volume determines which pricing tier applies. Specialty, number of providers, and specific services needed (billing, coding, credentialing, etc.) may also shape your proposal.",
  },
];
