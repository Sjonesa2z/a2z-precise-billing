import type { Service } from "@/types";
import {
  IconFileInvoice,
  IconCode,
  IconCycle,
  IconShieldAlert,
  IconSearchDollar,
  IconReceipt,
  IconClipboardCheck,
  IconClipboardList,
  IconUserCheck,
  IconTruckMedical,
  IconHomeHeart,
} from "@/components/icons";

export const services: Service[] = [
  {
    slug: "medical-billing",
    name: "Medical Billing",
    shortDescription:
      "End-to-end claim preparation, submission, and tracking for physicians and practices.",
    description:
      "We manage the core medical billing workflow — from charge entry through claim submission and tracking — so your team can focus on patient care instead of paperwork.",
    icon: IconFileInvoice,
    highlights: ["Charge entry", "Claim submission", "Claim tracking", "Payer follow-up"],
  },
  {
    slug: "medical-coding",
    name: "Medical Coding",
    shortDescription:
      "Accurate ICD-10, CPT, and HCPCS coding support aligned to documentation and payer requirements.",
    description:
      "Our coding support is focused on accuracy and consistency, helping translate clinical documentation into properly structured codes for cleaner claim submission.",
    icon: IconCode,
    highlights: ["ICD-10 & CPT coding support", "HCPCS coding support", "Documentation review", "Coding consistency checks"],
  },
  {
    slug: "revenue-cycle-management",
    name: "Revenue Cycle Management",
    shortDescription:
      "Coordinated support across the full billing cycle, from eligibility to final payment posting.",
    description:
      "We support the full revenue cycle — eligibility, charge capture, claims, payment posting, and follow-up — as a connected process rather than disconnected tasks.",
    icon: IconCycle,
    highlights: ["Full-cycle coordination", "Workflow visibility", "Process consistency", "Ongoing monitoring"],
  },
  {
    slug: "denial-management",
    name: "Denial Management",
    shortDescription:
      "Structured review, correction, and resubmission support for denied and rejected claims.",
    description:
      "When claims are denied, we review the reason codes, correct what's needed, and manage timely resubmission to help keep your claims moving.",
    icon: IconShieldAlert,
    highlights: ["Denial review", "Root-cause tracking", "Correction & resubmission", "Appeals support"],
  },
  {
    slug: "ar-follow-up",
    name: "A/R Follow-Up",
    shortDescription:
      "Consistent follow-up on outstanding claims to help reduce aged accounts receivable.",
    description:
      "We follow up on outstanding claims with payers on a regular cycle, prioritizing aging accounts and escalating issues that need practice input.",
    icon: IconSearchDollar,
    highlights: ["Aging A/R review", "Payer follow-up calls", "Priority escalation", "Status reporting"],
  },
  {
    slug: "payment-posting",
    name: "Payment Posting",
    shortDescription:
      "Timely, accurate posting of payments and adjustments from ERAs and EOBs.",
    description:
      "Payments and adjustments are posted from ERAs and EOBs in a consistent, auditable manner, helping keep your patient and payer balances current.",
    icon: IconReceipt,
    highlights: ["ERA/EOB posting", "Adjustment reconciliation", "Patient balance updates", "Reporting support"],
  },
  {
    slug: "eligibility-verification",
    name: "Eligibility Verification",
    shortDescription:
      "Insurance eligibility and benefits verification ahead of scheduled visits.",
    description:
      "We verify insurance eligibility and benefits ahead of scheduled visits to help reduce avoidable denials tied to coverage issues.",
    icon: IconClipboardCheck,
    highlights: ["Eligibility checks", "Benefits verification", "Coverage documentation", "Pre-visit review"],
  },
  {
    slug: "prior-authorization",
    name: "Prior Authorization",
    shortDescription:
      "Coordination of prior authorization requests for services that require payer approval.",
    description:
      "We coordinate prior authorization requests and track approval status for services that require it, helping reduce delays tied to missing authorizations.",
    icon: IconClipboardList,
    highlights: ["Authorization requests", "Status tracking", "Documentation coordination", "Payer communication"],
  },
  {
    slug: "credentialing",
    name: "Provider Credentialing",
    shortDescription:
      "Support with payer enrollment and credentialing documentation for providers and groups.",
    description:
      "We assist with payer enrollment and credentialing documentation, helping providers and groups navigate the administrative steps required to bill payers.",
    icon: IconUserCheck,
    highlights: ["Payer enrollment support", "Application tracking", "Documentation coordination", "Re-credentialing support"],
  },
  {
    slug: "dme-billing",
    name: "DME Billing",
    shortDescription:
      "Billing support for durable medical equipment providers, including documentation-heavy claims.",
    description:
      "DME billing involves detailed documentation and payer-specific rules. We support claim preparation and follow-up for equipment and supply categories.",
    icon: IconTruckMedical,
    highlights: ["Equipment claim prep", "Documentation coordination", "Payer-specific rules support", "Claim follow-up"],
  },
  {
    slug: "home-health-billing",
    name: "Home Health Billing",
    shortDescription:
      "Billing support for home health agencies across visit-based and episodic services.",
    description:
      "We support billing for home health agencies, including claims tied to nursing, therapy, and aide visits, with attention to episode and visit documentation.",
    icon: IconHomeHeart,
    highlights: ["Episode & visit billing", "Coding support", "Eligibility checks", "Claim follow-up"],
  },
];

export function getServiceBySlug(slug: string): Service | undefined {
  return services.find((service) => service.slug === slug);
}
