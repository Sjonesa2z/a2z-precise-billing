/**
 * Central site configuration.
 *
 * Values marked PLACEHOLDER must be replaced with verified business
 * information before launch. Do not publish placeholder contact
 * details, as they are not real and must not be presented as facts.
 */

export const siteConfig = {
  name: "A2Z Precise Billing",
  shortName: "A2Z Precise Billing",
  legalName: "A2Z Precise Billing",
  domain: "a2zprecisebillings.com",
  url: "https://a2zprecisebillings.com",
  industry: "Medical Billing & Revenue Cycle Management",
  yearsExperience: "17+",
  tagline: "Medical Billing & Revenue Cycle Management You Can Rely On",
  description:
    "A2Z Precise Billing provides professional medical billing, coding, DME, home health and RCM services backed by 17+ years of billing experience.",
  locale: "en-US",
  themeColor: "#12304A",

  // Verified business contact details.
  contact: {
    phoneDisplay: "(734) 619-8238",
    phoneHref: "tel:+17346198238",
    email: "sophiajonesa2z2@gmail.com",
    addressLine1: "PLACEHOLDER — Business Address Line 1",
    addressLine2: "PLACEHOLDER — City, State ZIP",
    hours: "Monday – Friday, 9:00 AM – 6:00 PM ET (PLACEHOLDER)",
  },

  // PLACEHOLDER — replace with verified, active social profiles only.
  social: {
    linkedin: "",
    facebook: "",
  },

  nav: {
    primary: [
      { label: "Home", href: "/" },
      { label: "About", href: "/about" },
      {
        label: "Services",
        href: "/services",
        children: [
          { label: "Medical Billing", href: "/services/medical-billing" },
          { label: "Medical Coding", href: "/services/medical-coding" },
          { label: "Revenue Cycle Management", href: "/services/revenue-cycle-management" },
          { label: "Denial Management", href: "/services/denial-management" },
          { label: "A/R Follow-Up", href: "/services/ar-follow-up" },
          { label: "Payment Posting", href: "/services/payment-posting" },
          { label: "Eligibility Verification", href: "/services/eligibility-verification" },
          { label: "Prior Authorization", href: "/services/prior-authorization" },
          { label: "Credentialing", href: "/services/credentialing" },
          { label: "DME Billing", href: "/services/dme-billing" },
          { label: "Home Health Billing", href: "/services/home-health-billing" },
        ],
      },
      { label: "Specialties", href: "/specialties" },
      { label: "Pricing", href: "/pricing" },
      { label: "How It Works", href: "/how-it-works" },
      { label: "Resources", href: "/resources" },
      { label: "Contact", href: "/contact" },
    ],
    footerLegal: [
      { label: "Privacy Policy", href: "/privacy-policy" },
      { label: "Terms of Service", href: "/terms" },
      { label: "HIPAA & Security", href: "/hipaa-security" },
    ],
  },

  cta: {
    primary: { label: "Get a Free Billing Assessment", href: "/request-assessment" },
    secondary: { label: "Explore Our Services", href: "/services" },
    pricing: { label: "Request Custom Pricing", href: "/contact" },
  },
} as const;

export type SiteConfig = typeof siteConfig;
