import type { ComponentType, SVGProps } from "react";

export type IconComponent = ComponentType<SVGProps<SVGSVGElement>>;

export interface Service {
  slug: string;
  name: string;
  shortDescription: string;
  description: string;
  icon: IconComponent;
  highlights: string[];
}

export interface Specialty {
  slug: string;
  name: string;
  description: string;
}

export interface Industry {
  slug: string;
  name: string;
  description: string;
  icon: IconComponent;
}

export interface FaqItem {
  question: string;
  answer: string;
  category?: string;
}

export interface ProcessStep {
  step: number;
  title: string;
  description: string;
}

export interface Benefit {
  title: string;
  description: string;
  icon: IconComponent;
}

export interface Testimonial {
  quote: string;
  author: string;
  role: string;
  organization: string;
}

export interface BreadcrumbItem {
  label: string;
  href: string;
}
