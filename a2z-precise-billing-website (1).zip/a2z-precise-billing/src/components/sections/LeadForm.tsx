"use client";

import { useId, useState, type FormEvent } from "react";
import { services } from "@/data/services";
import { specialties } from "@/data/specialties";
import { Button } from "@/components/ui/Button";

const organizationTypes = [
  "Physician / Solo Provider",
  "Medical Practice",
  "Clinic",
  "Home Health Agency",
  "DME Provider",
  "Healthcare Organization",
  "Other",
];

const claimVolumeRanges = [
  "Under 100 claims / month",
  "100–500 claims / month",
  "500–1,500 claims / month",
  "1,500+ claims / month",
  "Not sure yet",
];

type SubmitState = "idle" | "submitting" | "success" | "error";

interface FieldsetGroupProps {
  legend: string;
  htmlFor: string;
  children: React.ReactNode;
}

function FieldGroup({ legend, htmlFor, children }: FieldsetGroupProps) {
  return (
    <div>
      <label htmlFor={htmlFor} className="mb-1.5 block text-sm font-medium text-navy-700">
        {legend}
      </label>
      {children}
    </div>
  );
}

const inputClasses =
  "w-full rounded-control border border-border bg-white px-3.5 py-2.5 text-sm text-ink placeholder:text-ink-soft focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/25";

export function LeadForm() {
  const [state, setState] = useState<SubmitState>("idle");
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [selectedServices, setSelectedServices] = useState<string[]>([]);
  const formId = useId();

  function toggleService(name: string) {
    setSelectedServices((prev) =>
      prev.includes(name) ? prev.filter((s) => s !== name) : [...prev, name]
    );
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setState("submitting");
    setErrorMessage(null);

    const formData = new FormData(event.currentTarget);
    const payload = {
      fullName: String(formData.get("fullName") || ""),
      company: String(formData.get("company") || ""),
      email: String(formData.get("email") || ""),
      phone: String(formData.get("phone") || ""),
      organizationType: String(formData.get("organizationType") || ""),
      specialty: String(formData.get("specialty") || ""),
      servicesNeeded: selectedServices,
      claimVolume: String(formData.get("claimVolume") || ""),
      message: String(formData.get("message") || ""),
    };

    try {
      const response = await fetch("/api/lead", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        const data = (await response.json().catch(() => null)) as { error?: string } | null;
        throw new Error(data?.error || "Something went wrong. Please try again.");
      }

      setState("success");
      event.currentTarget.reset();
      setSelectedServices([]);
    } catch (error) {
      setState("error");
      setErrorMessage(error instanceof Error ? error.message : "Something went wrong. Please try again.");
    }
  }

  if (state === "success") {
    return (
      <div
        role="status"
        className="rounded-card border border-teal-200 bg-teal-50 p-6 text-center sm:p-8"
      >
        <h3 className="font-display text-lg font-semibold text-navy-700">Thank you — we received your request.</h3>
        <p className="mt-2 text-sm leading-relaxed text-ink-muted">
          A member of our team will follow up shortly to discuss your billing needs. If your
          request is time-sensitive, please call us directly.
        </p>
        <Button variant="outline" className="mt-5" onClick={() => setState("idle")}>
          Submit another request
        </Button>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} noValidate aria-describedby={errorMessage ? `${formId}-error` : undefined}>
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
        <FieldGroup legend="Full name" htmlFor={`${formId}-fullName`}>
          <input
            id={`${formId}-fullName`}
            type="text"
            name="fullName"
            required
            autoComplete="name"
            className={inputClasses}
            aria-required="true"
          />
        </FieldGroup>

        <FieldGroup legend="Practice / company" htmlFor={`${formId}-company`}>
          <input
            id={`${formId}-company`}
            type="text"
            name="company"
            required
            autoComplete="organization"
            className={inputClasses}
            aria-required="true"
          />
        </FieldGroup>

        <FieldGroup legend="Business email" htmlFor={`${formId}-email`}>
          <input
            id={`${formId}-email`}
            type="email"
            name="email"
            required
            autoComplete="email"
            className={inputClasses}
            aria-required="true"
          />
        </FieldGroup>

        <FieldGroup legend="Phone" htmlFor={`${formId}-phone`}>
          <input
            id={`${formId}-phone`}
            type="tel"
            name="phone"
            required
            autoComplete="tel"
            className={inputClasses}
            aria-required="true"
          />
        </FieldGroup>

        <FieldGroup legend="Organization type" htmlFor={`${formId}-organizationType`}>
          <select
            id={`${formId}-organizationType`}
            name="organizationType"
            required
            defaultValue=""
            className={inputClasses}
            aria-required="true"
          >
            <option value="" disabled>
              Select an option
            </option>
            {organizationTypes.map((type) => (
              <option key={type} value={type}>
                {type}
              </option>
            ))}
          </select>
        </FieldGroup>

        <FieldGroup legend="Specialty" htmlFor={`${formId}-specialty`}>
          <select
            id={`${formId}-specialty`}
            name="specialty"
            required
            defaultValue=""
            className={inputClasses}
            aria-required="true"
          >
            <option value="" disabled>
              Select a specialty
            </option>
            {specialties.map((specialty) => (
              <option key={specialty.slug} value={specialty.name}>
                {specialty.name}
              </option>
            ))}
          </select>
        </FieldGroup>

        <FieldGroup legend="Approximate monthly claim volume" htmlFor={`${formId}-claimVolume`}>
          <select
            id={`${formId}-claimVolume`}
            name="claimVolume"
            required
            defaultValue=""
            className={inputClasses}
            aria-required="true"
          >
            <option value="" disabled>
              Select a range
            </option>
            {claimVolumeRanges.map((range) => (
              <option key={range} value={range}>
                {range}
              </option>
            ))}
          </select>
        </FieldGroup>

        <div className="sm:col-span-2">
          <fieldset>
            <legend className="mb-2 text-sm font-medium text-navy-700">Services needed</legend>
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
              {services.map((service) => (
                <label key={service.slug} className="flex items-center gap-2.5 text-sm text-ink">
                  <input
                    type="checkbox"
                    className="h-4 w-4 rounded border-border text-blue-600 focus:ring-2 focus:ring-blue-500/40"
                    checked={selectedServices.includes(service.name)}
                    onChange={() => toggleService(service.name)}
                  />
                  {service.name}
                </label>
              ))}
            </div>
          </fieldset>
        </div>

        <div className="sm:col-span-2">
          <FieldGroup legend="Message (optional)" htmlFor={`${formId}-message`}>
            <textarea
              id={`${formId}-message`}
              name="message"
              rows={4}
              className={inputClasses}
              placeholder="Tell us more about your current billing workflow or challenges."
            />
          </FieldGroup>
        </div>
      </div>

      <p className="mt-4 text-xs leading-relaxed text-ink-soft">
        Please do not include patient names, dates of birth, insurance ID numbers, medical
        record numbers, or other protected health information in this form.
      </p>

      {errorMessage ? (
        <p id={`${formId}-error`} role="alert" className="mt-4 text-sm font-medium text-red-600">
          {errorMessage}
        </p>
      ) : null}

      <Button type="submit" size="lg" className="mt-6 w-full sm:w-auto" disabled={state === "submitting"}>
        {state === "submitting" ? "Submitting…" : "Request a Free Billing Assessment"}
      </Button>
    </form>
  );
}
