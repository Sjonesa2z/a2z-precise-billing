import Link from "next/link";
import { siteConfig } from "@/lib/site-config";
import { Button } from "@/components/ui/Button";
import { IconCheck } from "@/components/icons";

const trustPoints = [
  `${siteConfig.yearsExperience} Years of Experience`,
  "Professional Billing Support",
  "U.S. Healthcare Focus",
];

export function Hero() {
  return (
    <section className="relative overflow-hidden bg-navy-800">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -right-24 -top-24 h-[420px] w-[420px] rounded-full bg-blue-500/20 blur-3xl"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -left-32 bottom-0 h-[320px] w-[320px] rounded-full bg-teal-500/10 blur-3xl"
      />

      <div className="container relative grid grid-cols-1 items-center gap-12 py-16 sm:py-20 lg:grid-cols-[1.05fr_0.95fr] lg:py-28">
        <div>
          <p className="text-sm font-semibold tracking-wide text-teal-200">
            MEDICAL BILLING &amp; REVENUE CYCLE MANAGEMENT
          </p>
          <h1 className="mt-4 font-display text-4xl font-bold leading-[1.1] text-white sm:text-5xl lg:text-[3.25rem]">
            Medical Billing &amp; Revenue Cycle Management You Can Rely On
          </h1>
          <p className="mt-6 max-w-xl text-base leading-relaxed text-white/80 sm:text-lg">
            A2Z Precise Billing provides professional medical billing, coding, DME,
            home health, and revenue cycle management services for physicians,
            medical practices, clinics, home health agencies, and healthcare
            organizations.
          </p>
          <p className="mt-4 max-w-xl text-base leading-relaxed text-white/80 sm:text-lg">
            With {siteConfig.yearsExperience} years of medical billing experience, we help healthcare
            providers manage essential billing processes with greater accuracy,
            consistency, and efficiency.
          </p>

          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Button href={siteConfig.cta.primary.href} size="lg">
              {siteConfig.cta.primary.label}
            </Button>
            <Button href={siteConfig.cta.secondary.href} variant="outline" size="lg" className="border-white/30 text-white hover:border-white hover:text-white">
              {siteConfig.cta.secondary.label}
            </Button>
          </div>

          <ul className="mt-8 flex flex-wrap gap-x-6 gap-y-2 text-sm text-white/70">
            {trustPoints.map((point) => (
              <li key={point} className="flex items-center gap-2">
                <IconCheck className="h-4 w-4 text-teal-300" />
                {point}
              </li>
            ))}
          </ul>
        </div>

        <div className="relative">
          <ClaimJourneyGraphic />
        </div>
      </div>

      <Link
        href="#services"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-10 focus:rounded-control focus:bg-white focus:px-4 focus:py-2 focus:text-sm focus:font-semibold focus:text-navy-700"
      >
        Skip to services
      </Link>
    </section>
  );
}

/**
 * Original abstract illustration of a claim moving through the billing
 * cycle — submitted, reviewed, and paid — echoing the brand's
 * clock-and-checkmark motif without reproducing any third-party asset.
 */
function ClaimJourneyGraphic() {
  const stages = [
    { label: "Claim Submitted", sub: "Charge entry & coding" },
    { label: "Under Review", sub: "Eligibility & payer checks" },
    { label: "Paid & Posted", sub: "Payment posting complete" },
  ];

  return (
    <div className="mx-auto max-w-md rounded-card border border-white/10 bg-white/[0.04] p-6 shadow-raised backdrop-blur-sm sm:p-8">
      <div className="flex items-center justify-between">
        <span className="text-xs font-semibold uppercase tracking-wide text-white/50">
          Claim Lifecycle
        </span>
        <span className="rounded-full bg-teal-500/15 px-2.5 py-1 text-xs font-semibold text-teal-200">
          On Track
        </span>
      </div>

      <ol className="mt-6 flex flex-col gap-0">
        {stages.map((stage, index) => {
          const isLast = index === stages.length - 1;
          return (
            <li key={stage.label} className="relative flex gap-4 pb-8 last:pb-0">
              {!isLast ? (
                <span
                  aria-hidden="true"
                  className="absolute left-[15px] top-8 h-full w-px bg-gradient-to-b from-teal-400/60 to-white/10"
                />
              ) : null}
              <span
                className={`relative z-10 flex h-8 w-8 shrink-0 items-center justify-center rounded-full border-2 ${
                  isLast
                    ? "border-teal-300 bg-teal-400 text-navy-800"
                    : "border-teal-300/70 bg-navy-700 text-teal-200"
                }`}
              >
                <IconCheck className="h-4 w-4" />
              </span>
              <div>
                <p className="font-display text-sm font-semibold text-white">{stage.label}</p>
                <p className="mt-0.5 text-xs text-white/60">{stage.sub}</p>
              </div>
            </li>
          );
        })}
      </ol>

      <div className="mt-2 grid grid-cols-2 gap-3 border-t border-white/10 pt-6">
        <div>
          <p className="font-display text-2xl font-bold text-white">{siteConfig.yearsExperience}</p>
          <p className="text-xs text-white/60">Years of Experience</p>
        </div>
        <div>
          <p className="font-display text-2xl font-bold text-white">11</p>
          <p className="text-xs text-white/60">Core Billing Services</p>
        </div>
      </div>
    </div>
  );
}
