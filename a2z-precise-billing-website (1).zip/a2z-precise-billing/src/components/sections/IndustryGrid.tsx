import type { Industry } from "@/types";
import { industries } from "@/data/industries";

export function IndustryCard({ industry, tone = "light" }: { industry: Industry; tone?: "light" | "dark" }) {
  const Icon = industry.icon;

  if (tone === "dark") {
    return (
      <div className="flex flex-col items-start gap-3 rounded-card border border-white/10 bg-white/[0.04] p-5 backdrop-blur-sm">
        <span className="flex h-10 w-10 items-center justify-center rounded-control bg-white/10 text-teal-200">
          <Icon className="h-5 w-5" />
        </span>
        <h3 className="font-display text-base font-semibold text-white">{industry.name}</h3>
        <p className="text-sm leading-relaxed text-white/70">{industry.description}</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-start gap-3 rounded-card border border-border bg-surface p-5">
      <span className="flex h-10 w-10 items-center justify-center rounded-control bg-white text-teal-600 shadow-sm">
        <Icon className="h-5 w-5" />
      </span>
      <h3 className="font-display text-base font-semibold text-navy-700">{industry.name}</h3>
      <p className="text-sm leading-relaxed text-ink-muted">{industry.description}</p>
    </div>
  );
}

export function IndustryGrid({ tone = "light" }: { tone?: "light" | "dark" }) {
  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {industries.map((industry) => (
        <IndustryCard key={industry.slug} industry={industry} tone={tone} />
      ))}
    </div>
  );
}
