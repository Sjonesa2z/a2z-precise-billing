import {
  IconAccuracy,
  IconCycle,
  IconLedger,
  IconTruckMedical,
} from "@/components/icons";
import { siteConfig } from "@/lib/site-config";

const reasons = [
  {
    icon: IconAccuracy,
    title: `${siteConfig.yearsExperience} Years of Experience`,
    description: "Billing and coding support built on 17+ years of hands-on medical billing experience.",
  },
  {
    icon: IconCycle,
    title: "Full Revenue Cycle Coverage",
    description: "One team supporting billing, coding, denial management, and A/R follow-up together.",
  },
  {
    icon: IconTruckMedical,
    title: "DME & Home Health Focus",
    description: "Dedicated support for the documentation-heavy needs of DME and home health billing.",
  },
  {
    icon: IconLedger,
    title: "Transparent Pricing",
    description: "A straightforward, volume-based pricing structure with no hidden line items.",
  },
];

export function WhyChooseUs() {
  return (
    <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
      {reasons.map((reason) => {
        const Icon = reason.icon;
        return (
          <div key={reason.title} className="rounded-card border border-border bg-white p-6">
            <span className="flex h-11 w-11 items-center justify-center rounded-control bg-teal-50 text-teal-600">
              <Icon className="h-5 w-5" />
            </span>
            <h3 className="mt-4 font-display text-base font-semibold text-navy-700">{reason.title}</h3>
            <p className="mt-2 text-sm leading-relaxed text-ink-muted">{reason.description}</p>
          </div>
        );
      })}
    </div>
  );
}
