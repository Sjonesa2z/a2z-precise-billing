import Link from "next/link";
import type { Service } from "@/types";
import { services } from "@/data/services";
import { IconArrowRight } from "@/components/icons";

export function ServiceCard({ service }: { service: Service }) {
  const Icon = service.icon;
  return (
    <Link
      href={`/services/${service.slug}`}
      className="group relative flex flex-col rounded-card border border-border bg-white p-6 transition-shadow hover:shadow-card focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-500"
    >
      <span className="absolute inset-x-0 top-0 h-1 origin-left scale-x-0 rounded-t-card bg-teal-500 transition-transform duration-200 group-hover:scale-x-100" />
      <span className="flex h-11 w-11 items-center justify-center rounded-control bg-blue-50 text-blue-600">
        <Icon className="h-5 w-5" />
      </span>
      <h3 className="mt-4 font-display text-lg font-semibold text-navy-700">{service.name}</h3>
      <p className="mt-2 text-sm leading-relaxed text-ink-muted">{service.shortDescription}</p>
      <span className="mt-4 inline-flex items-center gap-1.5 text-sm font-semibold text-blue-600">
        Learn more
        <IconArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
      </span>
    </Link>
  );
}

export function ServiceGrid({ limit }: { limit?: number }) {
  const items = limit ? services.slice(0, limit) : services;
  return (
    <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
      {items.map((service) => (
        <ServiceCard key={service.slug} service={service} />
      ))}
    </div>
  );
}
