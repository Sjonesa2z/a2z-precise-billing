import type { IconComponent } from "@/types";
import { Button } from "@/components/ui/Button";
import { IconCheck } from "@/components/icons";

interface FeatureGroup {
  heading?: string;
  items: string[];
}

interface FeatureSectionProps {
  eyebrow?: string;
  title: string;
  description: string;
  groups: FeatureGroup[];
  ctaLabel: string;
  ctaHref: string;
  icon: IconComponent;
  reverse?: boolean;
  tone?: "surface" | "white";
}

export function FeatureSection({
  eyebrow,
  title,
  description,
  groups,
  ctaLabel,
  ctaHref,
  icon: Icon,
  reverse = false,
  tone = "white",
}: FeatureSectionProps) {
  return (
    <section className={tone === "surface" ? "bg-surface py-16 sm:py-20" : "bg-white py-16 sm:py-20"}>
      <div className="container">
        <div
          className={`grid grid-cols-1 items-center gap-10 lg:grid-cols-2 lg:gap-16 ${
            reverse ? "lg:[&>*:first-child]:order-2" : ""
          }`}
        >
          <div>
            {eyebrow ? (
              <p className="mb-3 text-sm font-semibold text-teal-600">{eyebrow}</p>
            ) : null}
            <h2 className="font-display text-3xl font-bold leading-tight text-navy-700 sm:text-4xl">
              {title}
            </h2>
            <p className="mt-4 max-w-xl text-base leading-relaxed text-ink-muted sm:text-lg">
              {description}
            </p>
            <Button href={ctaHref} variant="secondary" className="mt-6">
              {ctaLabel}
            </Button>
          </div>

          <div className="rounded-card border border-border bg-white p-6 shadow-card sm:p-8">
            <span className="flex h-12 w-12 items-center justify-center rounded-control bg-teal-50 text-teal-600">
              <Icon className="h-6 w-6" />
            </span>
            <div className="mt-6 flex flex-col gap-6">
              {groups.map((group, idx) => (
                <div key={group.heading ?? idx}>
                  {group.heading ? (
                    <h3 className="mb-3 text-xs font-semibold uppercase tracking-wide text-ink-soft">
                      {group.heading}
                    </h3>
                  ) : null}
                  <ul className="grid grid-cols-1 gap-x-4 gap-y-2.5 sm:grid-cols-2">
                    {group.items.map((item) => (
                      <li key={item} className="flex items-start gap-2 text-sm text-ink">
                        <IconCheck className="mt-0.5 h-4 w-4 shrink-0 text-teal-500" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
