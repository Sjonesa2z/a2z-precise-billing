import Link from "next/link";
import { specialties } from "@/data/specialties";

export function SpecialtyGrid({ limit }: { limit?: number }) {
  const items = limit ? specialties.slice(0, limit) : specialties;
  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
      {items.map((specialty) => (
        <Link
          key={specialty.slug}
          href={`/specialties/${specialty.slug}`}
          className="flex items-center justify-center rounded-control border border-border bg-white px-4 py-4 text-center text-sm font-medium text-navy-700 transition-colors hover:border-blue-400 hover:text-blue-600 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-500"
        >
          {specialty.name}
        </Link>
      ))}
    </div>
  );
}
