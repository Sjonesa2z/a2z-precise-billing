import { benefits } from "@/data/process";

export function BenefitGrid() {
  return (
    <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
      {benefits.map((benefit) => {
        const Icon = benefit.icon;
        return (
          <div key={benefit.title} className="flex items-start gap-4 rounded-card border border-border bg-white p-5">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-control bg-navy-50 text-navy-700">
              <Icon className="h-5 w-5" />
            </span>
            <div>
              <h3 className="font-display text-base font-semibold text-navy-700">{benefit.title}</h3>
              <p className="mt-1.5 text-sm leading-relaxed text-ink-muted">{benefit.description}</p>
            </div>
          </div>
        );
      })}
    </div>
  );
}
