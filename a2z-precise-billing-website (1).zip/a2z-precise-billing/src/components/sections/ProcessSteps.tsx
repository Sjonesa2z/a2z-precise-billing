import { processSteps } from "@/data/process";

export function ProcessSteps() {
  return (
    <ol className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
      {processSteps.map((step, index) => (
        <li key={step.step} className="relative rounded-card border border-border bg-white p-6">
          <span className="font-display text-sm font-bold text-teal-600">
            {String(step.step).padStart(2, "0")}
          </span>
          <h3 className="mt-3 font-display text-lg font-semibold text-navy-700">{step.title}</h3>
          <p className="mt-2 text-sm leading-relaxed text-ink-muted">{step.description}</p>
          {index < processSteps.length - 1 ? (
            <span
              aria-hidden="true"
              className="absolute -right-3 top-1/2 hidden h-px w-6 -translate-y-1/2 bg-border lg:block"
            />
          ) : null}
        </li>
      ))}
    </ol>
  );
}
