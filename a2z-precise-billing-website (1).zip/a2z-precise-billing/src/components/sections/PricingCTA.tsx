import Link from "next/link";
import { Button } from "@/components/ui/Button";
import { IconCheck } from "@/components/icons";

const tiers = [
  {
    name: "Practices up to $15,000/month",
    price: "$500",
    period: "per month, flat fee",
    features: ["Predictable flat monthly rate", "For lower monthly collection volume", "Core billing support included"],
  },
  {
    name: "Practices over $15,000/month",
    price: "3%",
    period: "of total monthly collections",
    features: ["Scales with your collections", "For higher monthly collection volume", "Core billing support included"],
  },
];

export function PricingCTA() {
  return (
    <section className="bg-navy-800 py-16 sm:py-20">
      <div className="container">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="font-display text-3xl font-bold text-white sm:text-4xl">
            Simple, Volume-Based Pricing
          </h2>
          <p className="mt-4 text-base leading-relaxed text-white/75 sm:text-lg">
            Every practice and healthcare organization has different billing
            volumes, specialties, workflows, and service requirements. Our
            base pricing structure is shown below — contact us to discuss
            your needs and request a customized service proposal.
          </p>
        </div>

        <div className="mx-auto mt-10 grid max-w-3xl grid-cols-1 gap-5 sm:grid-cols-2">
          {tiers.map((tier) => (
            <div key={tier.name} className="rounded-card border border-white/10 bg-white/[0.04] p-6 backdrop-blur-sm">
              <p className="text-sm font-medium text-white/60">{tier.name}</p>
              <p className="mt-3 font-display text-4xl font-bold text-white">
                {tier.price}
                <span className="ml-1 text-base font-medium text-white/50">/ {tier.period}</span>
              </p>
              <ul className="mt-5 flex flex-col gap-2.5">
                {tier.features.map((feature) => (
                  <li key={feature} className="flex items-start gap-2 text-sm text-white/75">
                    <IconCheck className="mt-0.5 h-4 w-4 shrink-0 text-teal-300" />
                    {feature}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-10 flex flex-col items-center gap-3">
          <Button href="/contact" size="lg">
            Request Custom Pricing
          </Button>
          <Link href="/pricing" className="text-sm font-medium text-teal-200 hover:text-white">
            See full pricing details
          </Link>
        </div>
      </div>
    </section>
  );
}
