import type { FaqItem } from "@/types";
import { IconChevronDown } from "@/components/icons";

export function FAQAccordion({ items }: { items: FaqItem[] }) {
  return (
    <div className="flex flex-col divide-y divide-border rounded-card border border-border bg-white">
      {items.map((item) => (
        <details key={item.question} className="group p-5 open:bg-surface/40 sm:p-6">
          <summary className="flex cursor-pointer list-none items-center justify-between gap-4 font-display text-base font-semibold text-navy-700 marker:content-none [&::-webkit-details-marker]:hidden">
            {item.question}
            <IconChevronDown className="h-5 w-5 shrink-0 text-ink-muted transition-transform duration-200 group-open:rotate-180" />
          </summary>
          <p className="mt-3 text-sm leading-relaxed text-ink-muted sm:text-base">{item.answer}</p>
        </details>
      ))}
    </div>
  );
}
