import type { Testimonial } from "@/types";

/**
 * No real testimonials have been supplied yet. This array is
 * intentionally empty — do not populate it with invented quotes.
 * Once verified client testimonials are available, add them here
 * following the Testimonial type.
 */
export const testimonials: Testimonial[] = [];

export function Testimonials() {
  if (testimonials.length === 0) {
    return (
      <div className="rounded-card border border-dashed border-border bg-surface p-8 text-center">
        <p className="text-sm font-medium text-ink-muted">
          Client testimonials will be added here once available.
        </p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
      {testimonials.map((testimonial) => (
        <figure
          key={`${testimonial.author}-${testimonial.organization}`}
          className="flex flex-col justify-between rounded-card border border-border bg-white p-6"
        >
          <blockquote className="text-sm leading-relaxed text-ink">&ldquo;{testimonial.quote}&rdquo;</blockquote>
          <figcaption className="mt-4 text-sm font-semibold text-navy-700">
            {testimonial.author}
            <span className="block text-xs font-normal text-ink-muted">
              {testimonial.role}, {testimonial.organization}
            </span>
          </figcaption>
        </figure>
      ))}
    </div>
  );
}
