import { siteConfig } from "@/lib/site-config";
import { services } from "@/data/services";
import { specialties } from "@/data/specialties";
import { industries } from "@/data/industries";

const stats = [
  { value: siteConfig.yearsExperience, label: "Years of Medical Billing Experience" },
  { value: String(services.length), label: "Core Billing & RCM Services" },
  { value: String(specialties.length - 1), label: "Specialties Supported" },
  { value: String(industries.length), label: "Types of Organizations Served" },
];

export function TrustStats() {
  return (
    <section className="border-y border-border bg-white py-12 sm:py-14">
      <div className="container">
        <div className="grid grid-cols-2 gap-8 sm:grid-cols-4">
          {stats.map((stat) => (
            <div key={stat.label} className="text-center sm:text-left">
              <p className="font-display text-3xl font-bold text-navy-700 sm:text-4xl">{stat.value}</p>
              <p className="mt-1.5 text-sm leading-snug text-ink-muted">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
