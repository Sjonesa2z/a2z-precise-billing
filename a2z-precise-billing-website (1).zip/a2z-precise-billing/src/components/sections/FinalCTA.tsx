import { siteConfig } from "@/lib/site-config";
import { Button } from "@/components/ui/Button";
import { IconPhone } from "@/components/icons";

export function FinalCTA() {
  return (
    <section className="bg-blue-500 py-14 sm:py-16">
      <div className="container flex flex-col items-center gap-6 text-center sm:flex-row sm:justify-between sm:text-left">
        <div>
          <h2 className="font-display text-2xl font-bold text-white sm:text-3xl">
            Ready to simplify your billing?
          </h2>
          <p className="mt-2 max-w-xl text-sm text-white/85 sm:text-base">
            Request a free billing assessment and we&apos;ll follow up to discuss your practice&apos;s needs.
          </p>
        </div>
        <div className="flex flex-col gap-3 sm:flex-row">
          <Button href={siteConfig.contact.phoneHref} variant="secondary" className="bg-navy-800 hover:bg-navy-900">
            <IconPhone className="h-4 w-4" />
            {siteConfig.contact.phoneDisplay}
          </Button>
          <Button href={siteConfig.cta.primary.href} className="bg-white text-blue-600 hover:bg-white/90">
            {siteConfig.cta.primary.label}
          </Button>
        </div>
      </div>
    </section>
  );
}
