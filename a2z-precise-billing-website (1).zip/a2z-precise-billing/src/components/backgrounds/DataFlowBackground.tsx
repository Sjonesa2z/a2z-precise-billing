/**
 * Original decorative background: flowing particle/data streams,
 * redrawn from scratch in the brand's navy/blue/teal palette as an
 * abstract representation of claims and data moving through a system.
 * Inspired by a reference the client shared, but no third-party
 * artwork is reproduced.
 *
 * Purely decorative: aria-hidden and positioned behind content.
 */
export function DataFlowBackground({ className = "" }: { className?: string }) {
  const streams = [
    "M-50,420 C150,380 250,460 450,380 S750,300 1250,340",
    "M-50,480 C200,440 300,520 500,440 S800,360 1250,400",
    "M-50,340 C180,300 280,380 480,300 S780,220 1250,260",
  ];

  const particles = [
    { x: 120, y: 400, r: 2.2 },
    { x: 260, y: 420, r: 1.6 },
    { x: 380, y: 370, r: 2.6 },
    { x: 520, y: 410, r: 1.8 },
    { x: 660, y: 350, r: 2.2 },
    { x: 800, y: 330, r: 1.6 },
    { x: 940, y: 360, r: 2.4 },
    { x: 1080, y: 320, r: 1.8 },
    { x: 200, y: 300, r: 1.6 },
    { x: 460, y: 260, r: 2 },
    { x: 720, y: 240, r: 1.6 },
    { x: 960, y: 260, r: 2.2 },
  ];

  return (
    <svg
      aria-hidden="true"
      className={className}
      viewBox="0 0 1200 500"
      preserveAspectRatio="xMidYMid slice"
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        <linearGradient id="flowStroke" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#168F8B" stopOpacity="0" />
          <stop offset="50%" stopColor="#2AABA6" stopOpacity="0.5" />
          <stop offset="100%" stopColor="#3B87C4" stopOpacity="0.15" />
        </linearGradient>
      </defs>

      {streams.map((d, i) => (
        <path key={i} d={d} fill="none" stroke="url(#flowStroke)" strokeWidth={1.4 - i * 0.2} />
      ))}

      <g fill="#7FD7D2">
        {particles.map((p, i) => (
          <circle key={i} cx={p.x} cy={p.y} r={p.r} opacity={0.4 + (i % 3) * 0.15} />
        ))}
      </g>
    </svg>
  );
}
