/**
 * Original decorative background: an abstract hexagon/network pattern
 * in the brand's navy/blue/teal palette. Inspired by a geometric
 * reference the client shared, but redrawn from scratch as brand-colored
 * vector shapes — no third-party artwork is reproduced.
 *
 * Purely decorative: aria-hidden and positioned behind content.
 */
export function HexagonBackground({ className = "" }: { className?: string }) {
  return (
    <svg
      aria-hidden="true"
      className={className}
      viewBox="0 0 1200 500"
      preserveAspectRatio="xMidYMid slice"
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        <linearGradient id="hexStroke" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#3B87C4" stopOpacity="0.55" />
          <stop offset="100%" stopColor="#168F8B" stopOpacity="0.35" />
        </linearGradient>
      </defs>

      {[
        "M120,40 L230,10 L330,60 L330,160 L230,210 L120,160 Z",
        "M330,60 L430,20 L530,70 L530,170 L430,220 L330,160 Z",
        "M760,20 L880,-20 L990,30 L990,150 L880,200 L760,140 Z",
        "M980,140 L1090,100 L1190,150 L1190,260 L1090,310 L980,250 Z",
        "M40,260 L150,220 L250,270 L250,380 L150,430 L40,370 Z",
        "M560,300 L680,260 L790,310 L790,430 L680,480 L560,420 Z",
        "M820,300 L920,270 L1010,320 L1010,420 L920,460 L820,410 Z",
      ].map((d, i) => (
        <path
          key={i}
          d={d}
          fill="none"
          stroke="url(#hexStroke)"
          strokeWidth="1.5"
          opacity={0.5 - i * 0.03}
        />
      ))}

      <g fill="#2AABA6" opacity="0.5">
        <circle cx="330" cy="60" r="2.5" />
        <circle cx="530" cy="170" r="2.5" />
        <circle cx="880" cy="200" r="2.5" />
        <circle cx="1090" cy="310" r="2.5" />
        <circle cx="250" cy="270" r="2.5" />
        <circle cx="680" cy="480" r="2.5" />
      </g>
    </svg>
  );
}
