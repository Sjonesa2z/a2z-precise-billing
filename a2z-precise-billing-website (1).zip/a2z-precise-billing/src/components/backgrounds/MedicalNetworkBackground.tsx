/**
 * Original decorative background: an abstract clinical data/network
 * motif (nodes connected around a central pulse), redrawn from scratch
 * in the brand's navy/blue/teal palette. No third-party artwork,
 * photography, or identifiable figures are used.
 *
 * Purely decorative: aria-hidden and positioned behind content.
 */
export function MedicalNetworkBackground({ className = "" }: { className?: string }) {
  return (
    <svg
      aria-hidden="true"
      className={className}
      viewBox="0 0 1200 500"
      preserveAspectRatio="xMidYMid slice"
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        <radialGradient id="pulseGlow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#2AABA6" stopOpacity="0.45" />
          <stop offset="100%" stopColor="#2AABA6" stopOpacity="0" />
        </radialGradient>
      </defs>

      <circle cx="960" cy="140" r="120" fill="url(#pulseGlow)" />

      <g stroke="#3B87C4" strokeWidth="1.2" opacity="0.4">
        <line x1="960" y1="140" x2="1080" y2="60" />
        <line x1="960" y1="140" x2="1120" y2="170" />
        <line x1="960" y1="140" x2="1030" y2="260" />
        <line x1="960" y1="140" x2="850" y2="80" />
        <line x1="960" y1="140" x2="840" y2="220" />
      </g>
      <g fill="#7FD7D2">
        <circle cx="1080" cy="60" r="4" />
        <circle cx="1120" cy="170" r="4" />
        <circle cx="1030" cy="260" r="4" />
        <circle cx="850" cy="80" r="4" />
        <circle cx="840" cy="220" r="4" />
        <circle cx="960" cy="140" r="6" />
      </g>

      {/* subtle vital-sign pulse line */}
      <path
        d="M0 400 L120 400 L150 340 L180 440 L210 400 L260 400 L290 370 L320 400 L1200 400"
        fill="none"
        stroke="#168F8B"
        strokeWidth="1.5"
        opacity="0.3"
      />

      {/* faint medical cross accents */}
      <g fill="#EAF3FB" opacity="0.06">
        <rect x="60" y="60" width="60" height="18" rx="4" />
        <rect x="79" y="41" width="18" height="60" rx="4" />
      </g>
      <g fill="#EAF3FB" opacity="0.05">
        <rect x="180" y="320" width="44" height="13" rx="3" />
        <rect x="195" y="305" width="13" height="44" rx="3" />
      </g>
    </svg>
  );
}
