import Link from "next/link";
import { siteConfig } from "@/lib/site-config";

export function AnnouncementBar() {
  return (
    <div className="bg-navy-800 text-white">
      <div className="container flex flex-wrap items-center justify-center gap-x-6 gap-y-1 py-2 text-center text-xs sm:text-sm">
        <span className="font-medium">
          {siteConfig.yearsExperience} Years of Medical Billing Experience
        </span>
        <span className="hidden text-white/40 sm:inline">|</span>
        <Link href="/request-assessment" className="font-semibold text-teal-100 hover:text-white">
          Get a Free Billing Assessment
        </Link>
      </div>
    </div>
  );
}
