import Link from "next/link";
import { siteConfig } from "@/lib/site-config";
import { services } from "@/data/services";
import { Logo } from "@/components/layout/Logo";
import { IconMail, IconPhone, IconPin } from "@/components/icons";

export function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-border bg-navy-800 pb-24 pt-14 text-white lg:pb-14">
      <div className="container">
        <div className="grid grid-cols-1 gap-10 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <Logo variant="light" />
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-white/70">
              Medical billing, coding, and revenue cycle management support for
              physicians, practices, clinics, home health agencies, and DME
              providers.
            </p>
            <p className="mt-4 text-sm font-medium text-teal-100">
              {siteConfig.yearsExperience} Years of Medical Billing Experience
            </p>
          </div>

          <div>
            <h2 className="text-sm font-semibold uppercase tracking-wide text-white/50">Services</h2>
            <ul className="mt-4 flex flex-col gap-2.5 text-sm">
              {services.slice(0, 7).map((service) => (
                <li key={service.slug}>
                  <Link href={`/services/${service.slug}`} className="text-white/75 hover:text-white">
                    {service.name}
                  </Link>
                </li>
              ))}
              <li>
                <Link href="/services" className="font-semibold text-teal-100 hover:text-white">
                  View All Services
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h2 className="text-sm font-semibold uppercase tracking-wide text-white/50">Company</h2>
            <ul className="mt-4 flex flex-col gap-2.5 text-sm">
              <li>
                <Link href="/about" className="text-white/75 hover:text-white">About</Link>
              </li>
              <li>
                <Link href="/specialties" className="text-white/75 hover:text-white">Specialties</Link>
              </li>
              <li>
                <Link href="/pricing" className="text-white/75 hover:text-white">Pricing</Link>
              </li>
              <li>
                <Link href="/how-it-works" className="text-white/75 hover:text-white">How It Works</Link>
              </li>
              <li>
                <Link href="/resources" className="text-white/75 hover:text-white">Resources</Link>
              </li>
              <li>
                <Link href="/contact" className="text-white/75 hover:text-white">Contact</Link>
              </li>
            </ul>
          </div>

          <div>
            <h2 className="text-sm font-semibold uppercase tracking-wide text-white/50">Contact</h2>
            <ul className="mt-4 flex flex-col gap-3 text-sm text-white/75">
              <li className="flex items-start gap-2.5">
                <IconPhone className="mt-0.5 h-4 w-4 shrink-0 text-teal-300" />
                <a href={siteConfig.contact.phoneHref} className="hover:text-white">
                  {siteConfig.contact.phoneDisplay}
                </a>
              </li>
              <li className="flex items-start gap-2.5">
                <IconMail className="mt-0.5 h-4 w-4 shrink-0 text-teal-300" />
                <a href={`mailto:${siteConfig.contact.email}`} className="hover:text-white">
                  {siteConfig.contact.email}
                </a>
              </li>
              <li className="flex items-start gap-2.5">
                <IconPin className="mt-0.5 h-4 w-4 shrink-0 text-teal-300" />
                <span>
                  {siteConfig.contact.addressLine1}
                  <br />
                  {siteConfig.contact.addressLine2}
                </span>
              </li>
            </ul>
            <Link
              href="/request-assessment"
              className="mt-5 inline-flex items-center justify-center rounded-control bg-teal-500 px-4 py-2.5 text-sm font-semibold text-white hover:bg-teal-600"
            >
              Get a Free Billing Assessment
            </Link>
          </div>
        </div>

        <div className="mt-12 flex flex-col gap-4 border-t border-white/10 pt-6 text-xs text-white/60 sm:flex-row sm:items-center sm:justify-between">
          <p>© {year} {siteConfig.legalName}. All rights reserved.</p>
          <ul className="flex flex-wrap gap-x-5 gap-y-2">
            {siteConfig.nav.footerLegal.map((item) => (
              <li key={item.href}>
                <Link href={item.href} className="hover:text-white">
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <p className="mt-6 max-w-3xl text-xs leading-relaxed text-white/45">
          A2Z Precise Billing provides administrative billing and revenue
          cycle support services. Nothing on this website constitutes legal,
          financial, or medical coding certification advice. Results vary by
          practice, payer mix, and billing volume.
        </p>
      </div>
    </footer>
  );
}
