"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { siteConfig } from "@/lib/site-config";
import { IconChevronDown, IconClose, IconMenu, IconPhone } from "@/components/icons";
import { Button } from "@/components/ui/Button";

export function MobileMenu() {
  const [open, setOpen] = useState(false);
  const [servicesOpen, setServicesOpen] = useState(false);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  useEffect(() => {
    function handleEscape(event: KeyboardEvent) {
      if (event.key === "Escape") setOpen(false);
    }
    window.addEventListener("keydown", handleEscape);
    return () => window.removeEventListener("keydown", handleEscape);
  }, []);

  return (
    <div className="lg:hidden">
      <button
        type="button"
        onClick={() => setOpen(true)}
        aria-expanded={open}
        aria-controls="mobile-menu"
        aria-label="Open menu"
        className="inline-flex h-10 w-10 items-center justify-center rounded-control text-navy-700 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-500"
      >
        <IconMenu className="h-6 w-6" />
      </button>

      {open ? (
        <div className="fixed inset-0 z-50">
          <button
            aria-label="Close menu"
            className="absolute inset-0 bg-navy-900/50"
            onClick={() => setOpen(false)}
          />
          <div
            id="mobile-menu"
            role="dialog"
            aria-modal="true"
            aria-label="Site navigation"
            className="absolute inset-y-0 right-0 flex w-[85%] max-w-sm flex-col overflow-y-auto bg-white p-5 shadow-raised"
          >
            <div className="flex items-center justify-between">
              <span className="font-display text-base font-bold text-navy-700">Menu</span>
              <button
                type="button"
                onClick={() => setOpen(false)}
                aria-label="Close menu"
                className="inline-flex h-10 w-10 items-center justify-center rounded-control text-navy-700 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-500"
              >
                <IconClose className="h-6 w-6" />
              </button>
            </div>

            <nav aria-label="Mobile" className="mt-4 flex-1">
              <ul className="flex flex-col divide-y divide-border">
                {siteConfig.nav.primary.map((item) => (
                  <li key={item.href}>
                    {item.children ? (
                      <div>
                        <button
                          type="button"
                          onClick={() => setServicesOpen((v) => !v)}
                          aria-expanded={servicesOpen}
                          aria-controls="mobile-services-submenu"
                          className="flex w-full items-center justify-between py-3.5 text-left text-base font-medium text-navy-700"
                        >
                          {item.label}
                          <IconChevronDown
                            className={`h-5 w-5 text-ink-muted transition-transform ${
                              servicesOpen ? "rotate-180" : ""
                            }`}
                          />
                        </button>
                        {servicesOpen ? (
                          <ul id="mobile-services-submenu" className="mb-2 flex flex-col gap-0.5 pl-4">
                            <li>
                              <Link
                                href={item.href}
                                onClick={() => setOpen(false)}
                                className="block py-2 text-sm font-semibold text-blue-600"
                              >
                                All Services
                              </Link>
                            </li>
                            {item.children.map((child) => (
                              <li key={child.href}>
                                <Link
                                  href={child.href}
                                  onClick={() => setOpen(false)}
                                  className="block py-2 text-sm text-ink-muted hover:text-navy-700"
                                >
                                  {child.label}
                                </Link>
                              </li>
                            ))}
                          </ul>
                        ) : null}
                      </div>
                    ) : (
                      <Link
                        href={item.href}
                        onClick={() => setOpen(false)}
                        className="block py-3.5 text-base font-medium text-navy-700"
                      >
                        {item.label}
                      </Link>
                    )}
                  </li>
                ))}
              </ul>
            </nav>

            <div className="mt-4 flex flex-col gap-3 border-t border-border pt-4">
              <a
                href={siteConfig.contact.phoneHref}
                className="inline-flex items-center justify-center gap-2 rounded-control border border-border px-5 py-3 text-sm font-semibold text-navy-700"
              >
                <IconPhone className="h-4 w-4" />
                {siteConfig.contact.phoneDisplay}
              </a>
              <Button href="/request-assessment" onClick={() => setOpen(false)} className="w-full">
                Get a Free Billing Assessment
              </Button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
