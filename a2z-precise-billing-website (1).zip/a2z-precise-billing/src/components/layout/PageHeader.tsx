import { HexagonBackground } from "@/components/backgrounds/HexagonBackground";
import { MedicalNetworkBackground } from "@/components/backgrounds/MedicalNetworkBackground";
import { DataFlowBackground } from "@/components/backgrounds/DataFlowBackground";

type BackgroundVariant = "default" | "hex" | "network" | "flow";

interface PageHeaderProps {
  eyebrow?: string;
  title: string;
  description?: string;
  background?: BackgroundVariant;
}

export function PageHeader({ eyebrow, title, description, background = "default" }: PageHeaderProps) {
  return (
    <section className="relative overflow-hidden bg-navy-800 py-14 sm:py-16">
      {background === "default" ? (
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -right-20 -top-20 h-72 w-72 rounded-full bg-blue-500/15 blur-3xl"
        />
      ) : null}

      {background === "hex" ? (
        <HexagonBackground className="pointer-events-none absolute inset-0 h-full w-full" />
      ) : null}

      {background === "network" ? (
        <MedicalNetworkBackground className="pointer-events-none absolute inset-0 h-full w-full" />
      ) : null}

      {background === "flow" ? (
        <DataFlowBackground className="pointer-events-none absolute inset-0 h-full w-full" />
      ) : null}

      <div className="container relative max-w-3xl">
        {eyebrow ? <p className="mb-3 text-sm font-semibold text-teal-200">{eyebrow}</p> : null}
        <h1 className="font-display text-3xl font-bold leading-tight text-white sm:text-4xl">{title}</h1>
        {description ? (
          <p className="mt-4 text-base leading-relaxed text-white/75 sm:text-lg">{description}</p>
        ) : null}
      </div>
    </section>
  );
}
