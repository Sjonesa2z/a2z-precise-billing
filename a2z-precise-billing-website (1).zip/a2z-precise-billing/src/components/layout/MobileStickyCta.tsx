import { siteConfig } from "@/lib/site-config";
import { IconPhone } from "@/components/icons";

export function MobileStickyCta() {
  return (
    <div className="fixed inset-x-0 bottom-0 z-30 flex border-t border-border bg-white shadow-raised lg:hidden">
      <a
        href={siteConfig.contact.phoneHref}
        className="flex flex-1 items-center justify-center gap-2 border-r border-border py-3.5 text-sm font-semibold text-navy-700"
      >
        <IconPhone className="h-4 w-4 text-teal-500" />
        Call Us
      </a>
      <a
        href={siteConfig.cta.primary.href}
        className="flex flex-1 items-center justify-center bg-teal-500 py-3.5 text-sm font-semibold text-white"
      >
        Get Free Assessment
      </a>
    </div>
  );
}
