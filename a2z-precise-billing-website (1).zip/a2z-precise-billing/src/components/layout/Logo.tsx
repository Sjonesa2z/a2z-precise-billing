import Link from "next/link";

interface LogoProps {
  variant?: "light" | "dark";
  className?: string;
}

/**
 * Original logo mark: a clock face combined with an ascending checkmark
 * line and a small medical cross accent — representing timely, accurate
 * billing for healthcare providers. Rendered as inline SVG so it scales
 * cleanly across the header, footer, and favicon use cases.
 */
export function LogoMark({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 44 44" className={className} aria-hidden="true">
      <circle cx="20" cy="20" r="14.5" fill="none" stroke="currentColor" strokeWidth="2.4" opacity="0.9" />
      <path d="M20 11v9l6 3.2" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" opacity="0.55" />
      <path
        d="M8.5 24.5 15 18l4 4 8.5-9.5"
        fill="none"
        stroke="#168F8B"
        strokeWidth="3.1"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path d="M23 15.5h6.5l-3 -3.4z" fill="#168F8B" />
      <g transform="translate(31,27)">
        <circle cx="4" cy="4" r="6.5" fill="#C1443C" />
        <path d="M4 1.4v5.2M1.4 4h5.2" stroke="white" strokeWidth="1.4" strokeLinecap="round" />
      </g>
    </svg>
  );
}

export function Logo({ variant = "dark", className = "" }: LogoProps) {
  const wordColor = variant === "light" ? "text-white" : "text-navy-700";
  const preciseColor = variant === "light" ? "text-white" : "text-[#B4443C]";

  return (
    <Link href="/" className={`group flex items-center gap-2.5 ${className}`} aria-label="A2Z Precise Billing, home">
      <LogoMark className={`h-9 w-9 shrink-0 ${variant === "light" ? "text-white" : "text-navy-700"}`} />
      <span className={`font-display text-lg font-bold leading-none ${wordColor}`}>
        a2z <span className={preciseColor}>precise</span> billing
      </span>
    </Link>
  );
}
