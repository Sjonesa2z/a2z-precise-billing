import Link from "next/link";
import { siteConfig } from "@/lib/site-config";
import { Logo } from "@/components/layout/Logo";
import { MobileMenu } from "@/components/layout/MobileMenu";
import { Button } from "@/components/ui/Button";
import { IconChevronDown, IconPhone } from "@/components/icons";

export function Header() {
  return (
    <header className="sticky top-0 z-40 border-b border-border bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/85">
      <div className="container flex items-center justify-between gap-4 py-3">
        <Logo />

        <nav aria-label="Primary" className="hidden lg:block">
          <ul className="flex items-center gap-1">
            {siteConfig.nav.primary.map((item) =>
              item.children ? (
                <li key={item.href} className="group relative">
                  <Link
                    href={item.href}
                    className="flex items-center gap-1 rounded-control px-3 py-2 text-sm font-medium text-navy-700 hover:text-blue-600 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-500"
                  >
                    {item.label}
                    <IconChevronDown className="h-4 w-4 text-ink-soft" />
                  </Link>
                  <div className="invisible absolute left-0 top-full z-50 w-72 translate-y-1 rounded-card border border-border bg-white p-2 opacity-0 shadow-raised transition-all duration-150 group-hover:visible group-hover:translate-y-0 group-hover:opacity-100 group-focus-within:visible group-focus-within:translate-y-0 group-focus-within:opacity-100">
                    <ul className="grid grid-cols-1">
                      {item.children.map((child) => (
                        <li key={child.href}>
                          <Link
                            href={child.href}
                            className="block rounded-control px-3 py-2 text-sm text-ink hover:bg-surface hover:text-blue-600"
                          >
                            {child.label}
                          </Link>
                        </li>
                      ))}
                    </ul>
                  </div>
                </li>
              ) : (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    className="block rounded-control px-3 py-2 text-sm font-medium text-navy-700 hover:text-blue-600 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-500"
                  >
                    {item.label}
                  </Link>
                </li>
              )
            )}
          </ul>
        </nav>

        <div className="hidden items-center gap-3 lg:flex">
          <a
            href={siteConfig.contact.phoneHref}
            className="flex items-center gap-2 text-sm font-semibold text-navy-700 hover:text-blue-600"
          >
            <IconPhone className="h-4 w-4 text-teal-500" />
            {siteConfig.contact.phoneDisplay}
          </a>
          <Button href={siteConfig.cta.primary.href} size="md">
            {siteConfig.cta.primary.label}
          </Button>
        </div>

        <MobileMenu />
      </div>
    </header>
  );
}
