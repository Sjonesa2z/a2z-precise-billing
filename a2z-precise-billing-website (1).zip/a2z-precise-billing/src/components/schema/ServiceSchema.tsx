import { siteConfig } from "@/lib/site-config";
import { services } from "@/data/services";

export function ServiceListSchema() {
  const data = {
    "@context": "https://schema.org",
    "@type": "ItemList",
    itemListElement: services.map((service, index) => ({
      "@type": "ListItem",
      position: index + 1,
      item: {
        "@type": "Service",
        name: service.name,
        description: service.shortDescription,
        url: `${siteConfig.url}/services/${service.slug}`,
        provider: {
          "@type": "MedicalBusiness",
          name: siteConfig.name,
        },
        areaServed: "US",
      },
    })),
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  );
}
