import type { SVGProps } from "react";

/**
 * Minimal, dependency-free icon set.
 * Consistent 24x24 stroke-based icons so the visual language stays
 * unified across services, specialties, and feature sections.
 */

type IconProps = SVGProps<SVGSVGElement>;

const base = {
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 1.75,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
};

export function IconFileInvoice(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <path d="M7 3h7l4 4v14a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1Z" />
      <path d="M14 3v4a1 1 0 0 0 1 1h4" />
      <path d="M9 13h6" />
      <path d="M9 16.5h4" />
      <path d="M9 9.5h2" />
    </svg>
  );
}

export function IconCode(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <path d="M6 4 2.5 12 6 20" />
      <path d="M18 4l3.5 8L18 20" />
      <path d="M13.5 4l-3 16" />
    </svg>
  );
}

export function IconCycle(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <path d="M20 11a8 8 0 0 0-14.6-4.6" />
      <path d="M4 4v4.2h4.2" />
      <path d="M4 13a8 8 0 0 0 14.6 4.6" />
      <path d="M20 20v-4.2h-4.2" />
    </svg>
  );
}

export function IconShieldAlert(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <path d="M12 3 4.5 6v6c0 4.5 3.2 7.7 7.5 9 4.3-1.3 7.5-4.5 7.5-9V6L12 3Z" />
      <path d="M12 8.5v4" />
      <path d="M12 15.75h.01" />
    </svg>
  );
}

export function IconSearchDollar(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <circle cx="10.5" cy="10.5" r="6.5" />
      <path d="m15.5 15.5 5 5" />
      <path d="M10.5 8v5" />
      <path d="M12.2 8.9c-.3-.5-1-.8-1.7-.8-1 0-1.9.6-1.9 1.5s.9 1.3 1.9 1.5c1 .2 1.9.6 1.9 1.5s-.9 1.5-1.9 1.5c-.8 0-1.4-.3-1.7-.8" />
    </svg>
  );
}

export function IconReceipt(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <path d="M6 3h12v18l-2.5-1.5L13 21l-2.5-1.5L8 21l-2-1.5V3Z" />
      <path d="M9 8h6" />
      <path d="M9 11.5h6" />
      <path d="M9 15h3.5" />
    </svg>
  );
}

export function IconClipboardCheck(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <rect x="6" y="4.5" width="12" height="16" rx="1.5" />
      <path d="M9.5 4.5V3.75A1.25 1.25 0 0 1 10.75 2.5h2.5A1.25 1.25 0 0 1 14.5 3.75V4.5" />
      <path d="m9.5 13 1.8 1.8L15 11" />
    </svg>
  );
}

export function IconClipboardList(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <rect x="6" y="4.5" width="12" height="16" rx="1.5" />
      <path d="M9.5 4.5V3.75A1.25 1.25 0 0 1 10.75 2.5h2.5A1.25 1.25 0 0 1 14.5 3.75V4.5" />
      <path d="M9 11h6" />
      <path d="M9 14.5h6" />
      <path d="M9 18h3.5" />
    </svg>
  );
}

export function IconUserCheck(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <circle cx="10" cy="8.5" r="3.25" />
      <path d="M4.5 20c.6-3.4 3-5.3 5.5-5.3" />
      <path d="m14.5 16.5 2 2 3.5-3.8" />
    </svg>
  );
}

export function IconWheelchair(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <circle cx="9.5" cy="15.5" r="5" />
      <circle cx="11" cy="5" r="1.4" />
      <path d="M11 7v5.5h5" />
      <path d="M11 12.5 8.5 20h3.5L14.5 15" />
      <path d="M19 15.5h2" />
    </svg>
  );
}

export function IconHomeHeart(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <path d="M4 11.5 12 4l8 7.5" />
      <path d="M6 10v9.5a1 1 0 0 0 1 1h3.5v-5.7h3v5.7H17a1 1 0 0 0 1-1V10" />
    </svg>
  );
}

export function IconStethoscope(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <path d="M6 3v6.5a4 4 0 0 0 8 0V3" />
      <path d="M10 9.5v3a5.5 5.5 0 0 0 11 0v-1.2" />
      <circle cx="19.5" cy="9.2" r="1.6" />
      <path d="M6 3a1.2 1.2 0 1 1-2.4 0A1.2 1.2 0 0 1 6 3Z" />
      <path d="M10 3a1.2 1.2 0 1 1-2.4 0A1.2 1.2 0 0 1 10 3Z" />
    </svg>
  );
}

export function IconBuilding(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <rect x="5" y="3.5" width="9" height="17" rx="1" />
      <rect x="14" y="9" width="5" height="11.5" rx="1" />
      <path d="M8 7h1.5M8 10.5h1.5M8 14h1.5" />
    </svg>
  );
}

export function IconClinic(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <path d="M4 20.5h16" />
      <path d="M6 20.5V9.5L12 5l6 4.5v11" />
      <path d="M12 10v5" />
      <path d="M9.5 12.5h5" />
    </svg>
  );
}

export function IconTruckMedical(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <path d="M3 7.5h10v9H3z" />
      <path d="M13 10.5h3.6L19.5 13v3.5H13z" />
      <circle cx="7" cy="18" r="1.6" />
      <circle cx="16.5" cy="18" r="1.6" />
      <path d="M6.5 11v3M5 12.5h3" />
    </svg>
  );
}

export function IconOrganization(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <circle cx="12" cy="5.5" r="2" />
      <path d="M12 7.5v3" />
      <circle cx="6" cy="16" r="2" />
      <circle cx="18" cy="16" r="2" />
      <path d="M8 15 12 10.5 16 15" />
    </svg>
  );
}

export function IconLungs(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <path d="M12 3v9" />
      <path d="M12 12c-1.5-2-4-2.3-5.5-1-2 1.7-1.8 6.8-.3 8.3 1.2 1.2 3-.1 3.3-1.8l.5-3" />
      <path d="M12 12c1.5-2 4-2.3 5.5-1 2 1.7 1.8 6.8.3 8.3-1.2 1.2-3-.1-3.3-1.8l-.5-3" />
    </svg>
  );
}

export function IconDroplet(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <path d="M12 3.5s6 6.7 6 10.8a6 6 0 1 1-12 0c0-4.1 6-10.8 6-10.8Z" />
    </svg>
  );
}

export function IconMonitor(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <rect x="3.5" y="5" width="17" height="11" rx="1.2" />
      <path d="M8 20h8M12 16v4" />
      <path d="M6.5 12.5 9 9l2 3 2.5-4.5L16 11h1.8" />
    </svg>
  );
}

export function IconHeartPulse(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <path d="M12 20.5s-7.5-4.6-9.5-9.4C1.3 7.7 3.3 4.5 6.6 4.5c1.9 0 3.4 1 4 2.4h2.8c.6-1.4 2.1-2.4 4-2.4 3.3 0 5.3 3.2 4.1 6.6-2 4.8-9.5 9.4-9.5 9.4Z" />
      <path d="M6 12.5h2.5l1.5-2.8 2 5.2 1.5-2.4H16" />
    </svg>
  );
}

export function IconBone(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <path d="M7.5 16.5 16.5 7.5" />
      <path d="M5.3 5.3a2 2 0 1 1 3.4 1.4 2 2 0 0 1-1.4 3.4L5.3 8.1a2 2 0 0 1 0-2.8Z" />
      <path d="M18.7 18.7a2 2 0 1 0-3.4-1.4 2 2 0 0 0 1.4-3.4l2 2a2 2 0 0 0 0 2.8Z" />
    </svg>
  );
}

export function IconBaby(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <circle cx="12" cy="7.5" r="3.2" />
      <path d="M9.2 9.5c-2.7 1-4.2 3.6-3.8 6.8.3 2.6 3 4.2 6.6 4.2s6.3-1.6 6.6-4.2c.4-3.2-1.1-5.8-3.8-6.8" />
      <path d="M10.3 7c.3.6.9 1 1.7 1s1.4-.4 1.7-1" />
    </svg>
  );
}

export function IconSkin(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <path d="M4.5 12c0-4.7 3.4-8.5 7.5-8.5s7.5 3.8 7.5 8.5-3.4 8.5-7.5 8.5-7.5-3.8-7.5-8.5Z" />
      <circle cx="9.5" cy="10.5" r="1" />
      <circle cx="14.5" cy="13.5" r="1.4" />
      <circle cx="12" cy="8" r="0.6" />
    </svg>
  );
}

export function IconStomach(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <path d="M9 3.5c-1.7.5-2.8 2-2.8 4 0 1.7 1 2.4 1 4 0 3-2.2 3.7-2.2 6.3a3.2 3.2 0 0 0 6.4 0c0-1.6 1.2-1.6 1.2 0a3.2 3.2 0 0 0 6.4-.3c0-3.4-2.8-4.4-2.8-8.2 0-2.7-1.7-5-4.2-5.5" />
    </svg>
  );
}

export function IconWound(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <path d="M4 12h3l1.5-3L11 15l1.8-6L14.5 12H20" />
      <circle cx="12" cy="12" r="9" />
    </svg>
  );
}

export function IconKidney(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <path d="M9 3.8c-2.7.5-4.5 3-4.5 6.2 0 2.6 1.4 3.5 1.4 6.1 0 3 2.1 4.4 4 4.4 1.6 0 2.6-1 2.6-2.5 0-2.6-2.5-2.6-2.5-5.4 0-2 1.6-3.1 3.3-2.7 2 .5 2.8 2.6 2.8 4.7 0 3.4-2 5.9-4.9 5.9" />
    </svg>
  );
}

export function IconStepOne(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <path d="M12 3v13" />
      <path d="m7 11 5 5 5-5" />
      <path d="M5 20.5h14" />
    </svg>
  );
}

export function IconWorkflow(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <rect x="3.5" y="4" width="6" height="5" rx="1" />
      <rect x="14.5" y="4" width="6" height="5" rx="1" />
      <rect x="9" y="15" width="6" height="5" rx="1" />
      <path d="M6.5 9v3.5h11V9" />
      <path d="M12 12.5V15" />
    </svg>
  );
}

export function IconLayers(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <path d="m12 3 8 4.3-8 4.3-8-4.3Z" />
      <path d="m4 12 8 4.3 8-4.3" />
      <path d="m4 16.2 8 4.3 8-4.3" />
    </svg>
  );
}

export function IconRocket(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <path d="M12 3c2.8 1.4 4.7 4.4 4.7 8.3 0 2-1 4.4-2.2 6l-2.5 2.7-2.5-2.7c-1.2-1.6-2.2-4-2.2-6C7.3 7.4 9.2 4.4 12 3Z" />
      <circle cx="12" cy="10.5" r="1.8" />
      <path d="M8 15.5 5.5 18M16 15.5 18.5 18" />
      <path d="M9.5 20.5 12 22l2.5-1.5" />
    </svg>
  );
}

export function IconAccuracy(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <circle cx="12" cy="12" r="8" />
      <circle cx="12" cy="12" r="4" />
      <circle cx="12" cy="12" r="0.6" fill="currentColor" />
      <path d="M12 3v2.5M12 18.5V21M3 12h2.5M18.5 12H21" />
    </svg>
  );
}

export function IconLedger(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <rect x="4.5" y="3.5" width="15" height="17" rx="1.2" />
      <path d="M8.5 8h7M8.5 11.5h7M8.5 15h4.5" />
    </svg>
  );
}

export function IconEfficiency(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <circle cx="12" cy="12" r="8.5" />
      <path d="M12 7.5V12l3 2" />
    </svg>
  );
}

export function IconVisibility(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12Z" />
      <circle cx="12" cy="12" r="3" />
    </svg>
  );
}

export function IconPhone(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <path d="M6.5 3.5h3l1.5 4-2 1.5a11 11 0 0 0 5.5 5.5l1.5-2 4 1.5v3a1.5 1.5 0 0 1-1.6 1.5A16.5 16.5 0 0 1 5 5.1 1.5 1.5 0 0 1 6.5 3.5Z" />
    </svg>
  );
}

export function IconMail(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <rect x="3.5" y="5.5" width="17" height="13" rx="1.5" />
      <path d="m4.5 6.5 7.5 6 7.5-6" />
    </svg>
  );
}

export function IconPin(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <path d="M12 21s7-6.4 7-12a7 7 0 1 0-14 0c0 5.6 7 12 7 12Z" />
      <circle cx="12" cy="9" r="2.4" />
    </svg>
  );
}

export function IconClock(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <circle cx="12" cy="12" r="8.5" />
      <path d="M12 7.5V12l3.2 2" />
    </svg>
  );
}

export function IconChevronDown(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <path d="m6 9 6 6 6-6" />
    </svg>
  );
}

export function IconMenu(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <path d="M4 6.5h16M4 12h16M4 17.5h16" />
    </svg>
  );
}

export function IconClose(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <path d="m5 5 14 14M19 5 5 19" />
    </svg>
  );
}

export function IconCheck(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <path d="m5 12.5 4.5 4.5L19 7" />
    </svg>
  );
}

export function IconArrowRight(props: IconProps) {
  return (
    <svg {...base} {...props}>
      <path d="M4 12h16M13 5l7 7-7 7" />
    </svg>
  );
}
