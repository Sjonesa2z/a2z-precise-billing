interface SectionHeadingProps {
  eyebrow?: string;
  title: string;
  description?: string;
  align?: "left" | "center";
  as?: "h2" | "h3";
  tone?: "dark" | "light";
}

export function SectionHeading({
  eyebrow,
  title,
  description,
  align = "left",
  as = "h2",
  tone = "dark",
}: SectionHeadingProps) {
  const Heading = as;
  const alignClasses = align === "center" ? "text-center mx-auto" : "text-left";
  const titleColor = tone === "light" ? "text-white" : "text-navy-700";
  const descColor = tone === "light" ? "text-white/75" : "text-ink-muted";
  const eyebrowColor = tone === "light" ? "text-teal-100" : "text-teal-600";

  return (
    <div className={`max-w-2xl ${alignClasses}`}>
      {eyebrow ? (
        <p className={`mb-3 text-sm font-semibold tracking-wide ${eyebrowColor}`}>{eyebrow}</p>
      ) : null}
      <Heading className={`font-display text-3xl font-bold leading-tight sm:text-4xl ${titleColor}`}>
        {title}
      </Heading>
      {description ? (
        <p className={`mt-4 text-base leading-relaxed sm:text-lg ${descColor}`}>{description}</p>
      ) : null}
    </div>
  );
}
